/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.cput.varsityapp.domain;

/**
 *
 * @author Asimbonge Mbende(221090754)
 */
public class N_O_K_DetailsPOJO {

    private String studentEmail,title, firstName, lastName, gender, email, CellNo, address;

    public N_O_K_DetailsPOJO() {
    }

    public N_O_K_DetailsPOJO(String email) {
        this.email = email;
    }

//    public N_O_K_DetailsPOJO(String title, String firstName, String lastName, String gender, String email, String CellNo, String address) {
//        this.title = title;
//        this.firstName = firstName;
//        this.lastName = lastName;
//        this.gender = gender;
//        this.email = email;
//        this.CellNo = CellNo;
//        this.address = address;
//    }

    public N_O_K_DetailsPOJO(String studentEmail, String title, String firstName, String lastName, String gender, String email, String CellNo, String address) {
        this.studentEmail = studentEmail;
        this.title = title;
        this.firstName = firstName;
        this.lastName = lastName;
        this.gender = gender;
        this.email = email;
        this.CellNo = CellNo;
        this.address = address;
    }

    public String getStudentEmail() {
        return studentEmail;
    }

    public void setStudentEmail(String studentEmail) {
        this.studentEmail = studentEmail;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCellNo() {
        return CellNo;
    }

    public void setCellNo(String CellNo) {
        this.CellNo = CellNo;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @Override
    public String toString() {
        String output = "Title: " + getTitle()
                + "\nFirst Name: " + getFirstName()
                + "\nLast Name: " + getLastName()
                + "\nGender: " + getGender()
                + "\nEmail: " + getEmail()
                + "\nCell Number: " + getCellNo()
                + "\nAddress: " + getAddress();
        return output;
    }
}
