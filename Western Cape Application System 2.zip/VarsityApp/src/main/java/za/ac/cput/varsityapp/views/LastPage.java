package za.ac.cput.varsityapp.views;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.table.*;
import za.ac.cput.varsityapp.dao.LastPageDAO;
import za.ac.cput.varsityapp.domain.SubmissionPagePOJO;

public class LastPage extends JFrame implements ActionListener {

    private JPanel pnNorth, pnCenter, pnSouth;
    private JLabel lblHeading, lblGif;
    private JButton btnSubmit, btnBack, btnExit;
    private Font font1, font2;
    private LastPageDAO lpDAO;
    private JTable table;

    private String studentEmail;

    public LastPage(String email) {
        setTitle("Submit Application");
        this.studentEmail = email;
        pnNorth = new JPanel();
        pnNorth.setBackground(Color.WHITE);
        pnCenter = new JPanel();
        pnCenter.setBackground(new Color(15, 194, 252));
        pnSouth = new JPanel();
        lpDAO = new LastPageDAO();

        // Changes the default java logo
        try {
            BufferedImage customIconImage = ImageIO.read(new File("Logo2.jpg"));
            // Set the custom icon for the JFrame
            setIconImage(customIconImage);
        } catch (IOException ex) {
            // Handle any errors while loading the image (optional)
            ex.printStackTrace();
        }

        font1 = new Font("Times New Roman", Font.BOLD, 28);
        font2 = new Font("Times New Roman", Font.ITALIC, 22);

        lblHeading = new JLabel("Submission Page");
        lblHeading.setHorizontalAlignment(SwingConstants.CENTER);
        lblHeading.setFont(font1);
        lblHeading.setForeground(new Color(10, 10, 10));
        lblGif = new JLabel(new ImageIcon("hva-hogeschool-van-amsterdam.gif"));

        btnSubmit = new JButton("Submit Application");
        btnSubmit.setPreferredSize(new Dimension(150, 35));
        btnSubmit.setBackground(new Color(39, 214, 53));

        btnBack = new JButton("Back");
        btnBack.setBackground(Color.red);
        btnBack.setPreferredSize(new Dimension(100, 35));

        btnExit = new JButton("Exit");
        //        btnExit.setBackground(Color.red);
        btnExit.setPreferredSize(new Dimension(100, 35));

        // Set up the layout of the GUI
        pnNorth.setLayout(new GridLayout(1, 1));
        pnCenter.setLayout(new GridLayout());
        pnSouth.setLayout(new GridLayout(1, 1));

//        pnCenter.add(lblGif); // Place the GIF in the center panel
//        JScrollPane scrollPane = new JScrollPane(table);
//        pnCenter.add(scrollPane); // Place the table in the south panel
        add(pnNorth, BorderLayout.NORTH);
        add(pnCenter, BorderLayout.CENTER);
        add(pnSouth, BorderLayout.SOUTH);

        pnNorth.add(lblHeading);

        pnSouth.add(btnBack);
        pnSouth.add(btnSubmit);
        pnSouth.add(btnExit);

        btnBack.setFont(font2);
        btnSubmit.setFont(font2);
        btnExit.setFont(font2);

        // Initialize the table
        initializeTable();

        // Add action listeners to the buttons
        btnBack.addActionListener(this);
        btnSubmit.addActionListener(this);
        btnExit.addActionListener(this);

        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(900, 600);
        this.setLocationRelativeTo(null);
        this.setVisible(true);
    }

//    // Initialize the table with data
//    private void initializeTable() {
//        String[] columnNames = {"Student Email", "Institution", "Course Name", "Student Number"};
//        DefaultTableModel model = new DefaultTableModel(columnNames, 0);
//
//        // Create a list to store the data
//        List<SubmissionPagePOJO> dataList = new ArrayList<>();
//
//        // Read the courses and populate the model
//        lpDAO.readCourses(dataList, studentEmail);
//
//        // Add data from the list to the table model
//        for (SubmissionPagePOJO data : dataList) {
//            Object[] rowData = {studentEmail, data.getInstitution(), data.getCourseName(), data.getStudNum()};
//            model.addRow(rowData);
//        }
//
//        // Create the JTable with the populated model
//        table = new JTable(model);
//        table.setRowHeight(25);
//// Set the preferred size of the table
//        table.setPreferredScrollableViewportSize(new Dimension(850, 400));
//        // Create a new panel to center the table
//        JPanel tablePanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
//        tablePanel.add(new JScrollPane(table));
//        // Set different column widths
//        TableColumnModel columnModel = table.getColumnModel();
//        columnModel.getColumn(0).setPreferredWidth(150); // Student Email column width
//        columnModel.getColumn(1).setPreferredWidth(280); // Institution column width
//        columnModel.getColumn(2).setPreferredWidth(280); // Course Name column width
//        columnModel.getColumn(3).setPreferredWidth(100); // Student Number column width
//        // Add the table panel to the center panel
//        pnCenter.add(tablePanel);
//
//    }
    // Initialize the table with data
private void initializeTable() {
    String[] columnNames = {"Student Email", "Institution", "Course Name", "Student Number"};
    DefaultTableModel model = new DefaultTableModel(columnNames, 0);

    // Create a list to store the data
    List<SubmissionPagePOJO> dataList = new ArrayList<>();

    // Read the courses and populate the model
    lpDAO.readCourses(dataList, studentEmail);

    // Add data from the list to the table model
    for (SubmissionPagePOJO data : dataList) {
        Object[] rowData = {studentEmail, data.getInstitution(), data.getCourseName(), data.getStudNum()};
        model.addRow(rowData);
    }

    // Create the JTable with the populated model
    table = new JTable(model) {
        @Override
        public Component prepareRenderer(TableCellRenderer renderer, int row, int column) {
            Component comp = super.prepareRenderer(renderer, row, column);
            setRowHeight(25);
            // Set alternating row colors (pink for even rows, gray for odd rows)
            if (row % 2 == 0) {
                comp.setBackground(new Color(223, 172, 190));
            } else {
                comp.setBackground(new Color(162, 163, 162));
            }

            // Check if the row is selected and set the background color to green
            if (isRowSelected(row)) {
                comp.setBackground(Color.GREEN);
            }

            return comp;
        }
    };
    
    // Set the preferred size of the table
    table.setPreferredScrollableViewportSize(new Dimension(850, 400));

    // Create a new panel to center the table
    JPanel tablePanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
    tablePanel.add(new JScrollPane(table));

    // Set different column widths
    TableColumnModel columnModel = table.getColumnModel();
    columnModel.getColumn(0).setPreferredWidth(150); // Student Email column width
    columnModel.getColumn(1).setPreferredWidth(280); // Institution column width
    columnModel.getColumn(2).setPreferredWidth(280); // Course Name column width
    columnModel.getColumn(3).setPreferredWidth(100); // Student Number column width

    // Add the table panel to the center panel
    pnCenter.add(tablePanel);
}
//private void initializeTable() {
//    String[] columnNames = {"Student Email", "Institution", "Course Name", "Student Number"};
//    DefaultTableModel model = new DefaultTableModel(columnNames, 0);
//
//    // Create a list to store the data
//    List<SubmissionPagePOJO> dataList = new ArrayList<>();
//
//    // Read the courses and populate the model
//    lpDAO.readCourses(dataList, studentEmail);
//
//    // Add data from the list to the table model
//    for (SubmissionPagePOJO data : dataList) {
//        Object[] rowData = {studentEmail, data.getInstitution(), data.getCourseName(), data.getStudNum()};
//        model.addRow(rowData);
//    }
//
//    // Create the JTable with the populated model
//    table = new JTable(model) {
//        @Override
//        public boolean isCellEditable(int row, int column) {
//            return false; // Make the table non-editable
//        }
//    };
//    table.setRowHeight(25);
//    table.setPreferredScrollableViewportSize(new Dimension(850, 400));
//
//    // Set a custom cell renderer for alternating row colors
//    table.setDefaultRenderer(Object.class, new AlternatingRowColorRenderer());
//
//    // Set the selection background color to green
//    table.setSelectionBackground(Color.GREEN);
//
//    // Add a ListSelectionListener to handle row selection
//    table.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
//        @Override
//        public void valueChanged(ListSelectionEvent e) {
//            if (!e.getValueIsAdjusting()) {
//                int selectedRow = table.getSelectedRow();
//                if (selectedRow >= 0) {
//                    // Change the background color of the selected row to green
//                    table.setSelectionBackground(Color.GREEN);
//                    // Repaint the table to apply the color change
//                    table.repaint();
//                }
//            }
//        }
//    });
//
//    // Set different column widths
//    TableColumnModel columnModel = table.getColumnModel();
//    columnModel.getColumn(0).setPreferredWidth(150); // Student Email column width
//    columnModel.getColumn(1).setPreferredWidth(280); // Institution column width
//    columnModel.getColumn(2).setPreferredWidth(280); // Course Name column width
//    columnModel.getColumn(3).setPreferredWidth(100); // Student Number column width
//
//    // Add the table to a JScrollPane
//    JScrollPane scrollPane = new JScrollPane(table);
//
//    // Add the scroll pane to the center panel
//    pnCenter.add(scrollPane);
//}
//
//
//class AlternatingRowColorRenderer extends DefaultTableCellRenderer {
//    private static final Color PINK = new Color(223, 172, 190); // Light pink color
//    private static final Color GRAY = new Color(240, 240, 240); // Light gray color
//
//    @Override
//    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
//        super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
//
//        // Set alternating row colors
//        if (row % 2 == 0) {
//            setBackground(PINK);
//        } else {
//            setBackground(GRAY);
//        }
//
//        return this;
//    }
//}

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnBack) {
            CourseFeeGUI courseFeeGUI = new CourseFeeGUI(studentEmail);
            courseFeeGUI.setCourseFeeGUI();
            dispose();
        }

        if (e.getSource() == btnSubmit) {
            // Call the saveStudentNumbers method to save the data
            boolean success = true; // Flag to track success

            for (int i = 0; i < table.getRowCount(); i++) {
                String email = (String) table.getValueAt(i, 0);
                String institution = (String) table.getValueAt(i, 1);
                String courseName = (String) table.getValueAt(i, 2);
                String studNum = (String) table.getValueAt(i, 3);

                SubmissionPagePOJO s_p_pojo = new SubmissionPagePOJO(email, institution, courseName, studNum);
                try {
                    lpDAO.saveStudentNumbers(s_p_pojo);
                } catch (SQLException ex) {
                    Logger.getLogger(LastPage.class.getName()).log(Level.SEVERE, null, ex);
                    success = false; // Set the success flag to false on error
                }
            }

            if (success) {
                JOptionPane.showMessageDialog(this, "Your application has been successfully submitted.\nGood luck!",
                        "Application Submission", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "An error occurred while saving data to the database.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else if (e.getSource() == btnExit) {
            // Display a message
            JOptionPane.showMessageDialog(this, "Thank you for using our system.\nEnjoy the rest of your day.byee!",
                    "Exiting the application", JOptionPane.INFORMATION_MESSAGE);
            System.exit(0);
        }
    }

}
