/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package za.ac.cput.varsityapp.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import za.ac.cput.varsityapp.domain.User;
/**
 *
 * @author Skhoma
 */




public class UserDAO {
    private final String url ="jdbc:derby://localhost:1527/VarsityDB";
    private final String username = "administrator";
    private final String password = "password";

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(url, username, password);
    }

    public void saveUser(User user) {
        try (Connection conn = getConnection()) {
            String query = "INSERT INTO users (name, surname, username, dateOfBirth, password, firstSchool, firstPet, cityBorn, oldestCousin) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement statement = conn.prepareStatement(query);

            statement.setString(1, user.getName());
            statement.setString(2, user.getSurname());
            statement.setString(3, user.getUsername());
            statement.setString(4, user.getDateOfBirth());
            statement.setString(5, user.getPassword());
            statement.setString(6, user.getFirstSchool());
            statement.setString(7, user.getFirstPet());
            statement.setString(8, user.getCityBorn());
            statement.setString(9, user.getOldestCousin());

            statement.executeUpdate();
            System.out.println("User saved successfully!");
        } catch (SQLException e) {
            System.out.println("Error saving user: " + e.getMessage());
        }
    }
    public boolean checkUsernameExists(String username) {
    try (Connection conn = getConnection()) {
        // Prepare the SQL query to check if the username exists
        String query = "SELECT * FROM users WHERE username = ?";
        PreparedStatement preparedStatement = conn.prepareStatement(query);
        preparedStatement.setString(1, username);

        // Execute the query to check if the username exists
        ResultSet resultSet = preparedStatement.executeQuery();
        return resultSet.next(); // Returns true if the username exists, false otherwise
    } catch (SQLException e) {
        e.printStackTrace();
        return false; // Return false in case of an exception
    }
}

    public boolean checkUserExistence(String username, String firstSchool, String firstPet, String cityBorn, String oldestCousin) {
        try (Connection conn = getConnection()) {
            // Prepare the SQL query to check if the user exists
            String query = "SELECT * FROM users WHERE username = ? AND firstSchool = ? AND firstPet = ? AND cityBorn = ? AND oldestCousin = ?";
            PreparedStatement preparedStatement = conn.prepareStatement(query);
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, firstSchool);
            preparedStatement.setString(3, firstPet);
            preparedStatement.setString(4, cityBorn);
            preparedStatement.setString(5, oldestCousin);

            // Execute the query to check if the user exists
            ResultSet resultSet = preparedStatement.executeQuery();
            return resultSet.next(); // Returns true if the user exists, false otherwise
        } catch (SQLException e) {
            e.printStackTrace();
            return false; // Return false in case of an exception
        }
    }

    public User getUserByUsername(String username) {
        try (Connection conn = getConnection()) {
            // Prepare the SQL query to retrieve the user by username
            String query = "SELECT * FROM users WHERE username = ?";
            PreparedStatement preparedStatement = conn.prepareStatement(query);
            preparedStatement.setString(1, username);

            // Execute the query to retrieve the user data
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                // Create a User object from the retrieved data
                String name = resultSet.getString("name");
                String surname = resultSet.getString("surname");
                String dateOfBirth = resultSet.getString("dateOfBirth");
                String password = resultSet.getString("password");
                String firstSchool = resultSet.getString("firstSchool");
                String firstPet = resultSet.getString("firstPet");
                String cityBorn = resultSet.getString("cityBorn");
                String oldestCousin = resultSet.getString("oldestCousin");
                return new User(name, surname, username, dateOfBirth, password, firstSchool, firstPet, cityBorn, oldestCousin);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null; // Return null if the user does not exist
    }
    public boolean login(String username, String password) {
        try (Connection conn = getConnection()) {
            // Prepare the SQL query to check if the user exists with the provided credentials
            String query = "SELECT * FROM users WHERE username = ? AND password = ?";
            PreparedStatement preparedStatement = conn.prepareStatement(query);
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, password);

            // Execute the query to check if the user exists
            ResultSet resultSet = preparedStatement.executeQuery();
            return resultSet.next(); // Returns true if the user exists with the provided credentials, false otherwise
        } catch (SQLException e) {
            e.printStackTrace();
            return false; // Return false in case of an exception
        }
    }
   
     
public void updatePassword(String username, String newPassword) {
        try (Connection conn = getConnection()) {
            String query = "UPDATE users SET password = ? WHERE username = ?";
            try (PreparedStatement preparedStatement = conn.prepareStatement(query)) {
                preparedStatement.setString(1, newPassword);
                preparedStatement.setString(2, username);

                preparedStatement.executeUpdate();
                System.out.println("Password updated successfully!");
            } catch (SQLException e) {
                System.out.println("Error updating password: " + e.getMessage());
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

   public void deleteUser(String username) {
        try (Connection conn = getConnection()) {
            String query = "DELETE FROM users WHERE username = ?";
            try (PreparedStatement statement = conn.prepareStatement(query)) {
                statement.setString(1, username);
                int rowsDeleted = statement.executeUpdate();
                if (rowsDeleted > 0) {
                    System.out.println("User deleted successfully!");
                } else {
                    System.out.println("No user found with the provided username.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}