/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package za.ac.cput.varsityapp.views;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.util.Date;
//import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import org.apache.commons.validator.routines.EmailValidator;
import za.ac.cput.varsityapp.dao.UserDAO;
import za.ac.cput.varsityapp.domain.User;

/**
 *
 * @author Skhoma
 */
public class Register extends JFrame implements ActionListener {

    private JLabel lblLogo, lblHeading, lblName, lblSurname, lblEmail, lblDateOfBirth, lblPassword,
            lblConfirmPassword, lblTerms, lblSecurityQuestions,
            lblFirstSchool, lblFirstPet, lblCityBorn, lblOldestCousin, lblAnswerQuestions, lblSpace;
    private JPanel panel;
    private JPanel panelNorth, panelSouth, panelEast, panelWest, panelCenter;
    private JTextField txtName, txtSurname, txtEmail, txtDateOfBirth,
            txtFirstSchool, txtFirstPet, txtCityBorn, txtOldestCousin;
    private JPasswordField txtPassword, txtConfirmPassword;
    private JCheckBox Checkterms;
    private JButton btnRegister, btnBack, btnClear, btnExit;
    private UserDAO userDAO;
    private Font font1, font2, font3;

    public Register() {
        super("Register");
        userDAO = new UserDAO();
        font1 = new Font("Times New Roman", Font.BOLD, 28);
        font2 = new Font("Times New Roman", Font.ITALIC, 22);
        font3 = new Font("Arial", Font.BOLD, 15);
        ImageIcon imageIcon = new ImageIcon("./PRMLogo.png");
        Image image = imageIcon.getImage();
        Image newimg = image.getScaledInstance(250, 150, java.awt.Image.SCALE_SMOOTH);
        imageIcon = new ImageIcon(newimg);
        lblLogo = new JLabel("", imageIcon, SwingConstants.LEFT);
        lblHeading = new JLabel("Registration Form");
        lblHeading.setFont(font1);
        // lblLogo.setFont(new Font("Arial", Font.PLAIN, 30));
        lblName = new JLabel("First Name");
        lblName.setFont(font3);
        lblSurname = new JLabel("Last Name");
        lblSurname.setFont(font3);
        lblEmail = new JLabel("Email");
        lblEmail.setFont(font3);
        lblDateOfBirth = new JLabel("Date Of Birth(yyyy-MM-dd)");
        lblDateOfBirth.setFont(font3);
        lblPassword = new JLabel("Password");
        lblPassword.setFont(font3);
        lblConfirmPassword = new JLabel("Confirm Password ");
        lblConfirmPassword.setFont(font3);
        lblTerms = new JLabel("Accept Terms & Conditions");
        lblTerms.setFont(font3);
        lblSecurityQuestions = new JLabel("In case you forget your password, please fill in the Security Questions ");
        lblSecurityQuestions.setFont(font3);
        Checkterms = new JCheckBox();

        txtName = new JTextField(20);
        txtName.setFont(font3);
        txtSurname = new JTextField(20);
        txtSurname.setFont(font3);
        txtEmail = new JTextField(20);
        txtEmail.setFont(font3);
        txtDateOfBirth = new JTextField(20);
        txtDateOfBirth.setFont(font3);
        txtPassword = new JPasswordField(20);
        txtPassword.setFont(font3);
        txtConfirmPassword = new JPasswordField(20);
        txtConfirmPassword.setFont(font3);

        txtFirstSchool = new JTextField(20);
        txtFirstSchool.setFont(font3);
        txtFirstPet = new JTextField(20);
        txtFirstPet.setFont(font3);
        txtCityBorn = new JTextField(20);
        txtCityBorn.setFont(font3);
        txtOldestCousin = new JTextField(20);
        txtOldestCousin.setFont(font3);

        lblFirstSchool = new JLabel("What was the name of the first school you attending?");
        lblFirstPet = new JLabel("What was your first pet's name?");
        lblCityBorn = new JLabel("what's the name of the city you were born?");
        lblOldestCousin = new JLabel("What is the name of your oldest cousin?");
        lblAnswerQuestions = new JLabel("In case you forget your password, please fill in the Security Questions ");
        lblAnswerQuestions.setForeground(Color.RED);
        // lblAnswerQuestions.setFont(new Font("Arial", Font.PLAIN, 16));
        lblSpace = new JLabel("  ");

        btnRegister = new JButton("Register");
        btnRegister.setFont(font2);
        btnBack = new JButton("Back");
        btnBack.setFont(font2);
        btnClear = new JButton("Clear");
        btnClear.setFont(font2);
        btnExit = new JButton("Exit");
        btnExit.setFont(font2);

        panelNorth = new JPanel();
        panelCenter = new JPanel();
        panelEast = new JPanel();
        panelSouth = new JPanel();

        panelNorth.add(lblLogo);
        panelNorth.add(lblHeading);
        panelNorth.setLayout(new FlowLayout());
        panelCenter.setLayout(new GridLayout(12, 2));
        panelSouth.setLayout(new GridLayout(1, 4));

        panelCenter.add(lblName);
        panelCenter.add(lblSurname);
        panelCenter.add(txtName);
        panelCenter.add(txtSurname);

        panelCenter.add(lblEmail);
        panelCenter.add(lblDateOfBirth);
        panelCenter.add(txtEmail);
        panelCenter.add(txtDateOfBirth);

        panelCenter.add(lblPassword);
        panelCenter.add(lblConfirmPassword);
        panelCenter.add(txtPassword);
        panelCenter.add(txtConfirmPassword);
        panelCenter.add(lblAnswerQuestions);
        panelCenter.add(lblSpace);
        //panelCenter.add(lblTerms);
        // panelCenter.add(Checkterms);

        panelCenter.add(lblFirstSchool);
        panelCenter.add(lblFirstPet);
        panelCenter.add(txtFirstSchool);
        panelCenter.add(txtFirstPet);
        panelCenter.add(lblCityBorn);
        panelCenter.add(lblOldestCousin);
        panelCenter.add(txtCityBorn);
        panelCenter.add(txtOldestCousin);

        panelSouth.add(btnBack);
        panelSouth.add(btnRegister);
        panelSouth.add(btnClear);
        panelSouth.add(btnExit);
        panelCenter.add(lblTerms);
        panelCenter.add(Checkterms);

        btnRegister.setBackground(Color.orange);
        btnBack.setBackground(Color.GREEN);
        btnClear.setBackground(Color.PINK);
        btnExit.setBackground(Color.RED);

        panelNorth.setBackground(new Color(15, 194, 252));
        panelCenter.setBackground(new Color(15, 194, 252));
        panelEast.setBackground(new Color(15, 194, 252));
        panelSouth.setBackground(new Color(15, 194, 252));
        this.getContentPane().setBackground(new Color(15, 194, 252));
    }

    public void setRegisterGui() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(900, 600);
        setLocationRelativeTo(null);
        this.setVisible(true); // Set the frame visible
        this.add(panelNorth, BorderLayout.NORTH);
        this.add(panelCenter, BorderLayout.CENTER);
        this.add(panelEast, BorderLayout.EAST);
        this.add(panelSouth, BorderLayout.SOUTH);
        // Add the ActionListener to the btnRegister button
        btnRegister.addActionListener(this);
        btnBack.addActionListener(this);
        btnClear.addActionListener(this);
        btnExit.addActionListener(this);
    }

// Define a method to validate the date of birth
    private boolean validateDateOfBirth(String dateOfBirth) {
        // Define the date format you expect (e.g., "yyyy-MM-dd")
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        dateFormat.setLenient(false);

        try {
            // Parse the dateOfBirth string
            Date dob = dateFormat.parse(dateOfBirth);

            // Check if the parsed date is before the current date (not in the future)
            Date currentDate = new Date();
            if (dob.after(currentDate)) {
                JOptionPane.showMessageDialog(this, "Date of Birth cannot be in the future.", "Error", JOptionPane.ERROR_MESSAGE);
                return false;
            }

            // Date of birth is valid
            return true;
        } catch (ParseException e) {
            // Date format is not valid
            // JOptionPane.showMessageDialog(this, "Please provide a valid date of birth in the format yyyy-MM-dd.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }

    private boolean inputValidation() {
        String name = txtName.getText();
        String surname = txtSurname.getText();
        String username = txtEmail.getText();
        String dateOfBirth = txtDateOfBirth.getText();
        String password = new String(txtPassword.getPassword());
        String confirmPassword = new String(txtConfirmPassword.getPassword());
        String firstSchool = txtFirstSchool.getText();
        String firstPet = txtFirstPet.getText();
        String cityBorn = txtCityBorn.getText();
        String oldestCousin = txtOldestCousin.getText();

        // Perform input validation
        if (name.isEmpty() || surname.isEmpty() || username.isEmpty() || dateOfBirth.isEmpty()
                || password.isEmpty() || confirmPassword.isEmpty() || firstSchool.isEmpty()
                || firstPet.isEmpty() || cityBorn.isEmpty() || oldestCousin.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all the fields.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        if (name.length() < 2 || !name.matches("^[a-zA-Z ]+$")) {
            lblName.setText("Please provide a valid name*");
            lblName.setForeground(Color.RED);
            return false;
        } else {
            lblName.setText("First Name");
            lblName.setForeground(Color.BLACK);
        }

        if (surname.length() < 2 || !surname.matches("^[a-zA-Z ]+$")) {

            lblSurname.setText("Please provide a valid last name*");
            lblSurname.setForeground(Color.RED);
            //JOptionPane.showMessageDialog(this, "Please provide a valid first name", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        } else {
            lblSurname.setText("Last Name");
            lblSurname.setForeground(Color.BLACK);
        }
        if (!EmailValidator.getInstance().isValid(txtEmail.getText())) {
            lblEmail.setText("Please provide a valid email address*");
            lblEmail.setForeground(Color.RED);
//            JOptionPane.showMessageDialog(this, "Please provide a valid email address", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        } else {
            lblEmail.setText("Username");
            lblEmail.setForeground(Color.BLACK);
        }
        // Validate Date of Birth
        if (!validateDateOfBirth(dateOfBirth)) {
            lblDateOfBirth.setText("Please provide a valid date of birth in the format yyyy-MM-dd.");
            lblDateOfBirth.setForeground(Color.RED);
            return false;
        } else {
            lblDateOfBirth.setText("Date of Birth");
            lblDateOfBirth.setForeground(Color.BLACK);
        }
        if (!password.equals(confirmPassword)) {
            lblConfirmPassword.setText("Passwords do not match*");
            lblConfirmPassword.setForeground(Color.RED);
//            JOptionPane.showMessageDialog(this, "Passwords do not match.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        } else {
            lblConfirmPassword.setText("Confirm Password");
            lblConfirmPassword.setForeground(Color.BLACK);
        }
        if (firstSchool.length() < 2 || !firstSchool.matches("^[a-zA-Z ]+$")) {
            lblFirstSchool.setText("Please provide a valid school name*");
            lblFirstSchool.setForeground(Color.RED);
            //JOptionPane.showMessageDialog(this, "Please provide a valid school name", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        } else {
            lblFirstSchool.setText("What was the name of the first school you attending?*");
            lblFirstSchool.setForeground(Color.BLACK);
        }
        if (firstPet.length() < 2 || !firstPet.matches("[a-zA-Z]+")) {
            lblFirstPet.setText("Please provide a valid pet name");
            lblFirstPet.setForeground(Color.RED);
            //JOptionPane.showMessageDialog(this, "Please provide a valid school name", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        } else {
            lblFirstPet.setText("What was your first pet's name?");
            lblFirstPet.setForeground(Color.BLACK);
        }
        if (cityBorn.length() < 2 || !cityBorn.matches("^[a-zA-Z ]+$")) {
            lblCityBorn.setText("Please provide a valid city name");
            lblCityBorn.setForeground(Color.RED);
            //JOptionPane.showMessageDialog(this, "Please provide a valid school name", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        } else {
            lblCityBorn.setText("what's the name of the city you were born?");
            lblCityBorn.setForeground(Color.BLACK);
        }

        if (oldestCousin.length() < 2 || !oldestCousin.matches("^[a-zA-Z ]+$")) {
            lblOldestCousin.setText("Please provide a valid oldest cousin name*");
            lblOldestCousin.setForeground(Color.RED);
//JOptionPane.showMessageDialog(this, "Please provide a valid cousin name", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        } else {
            lblOldestCousin.setText("What is the name of your oldest cousin?*");
            lblOldestCousin.setForeground(Color.BLACK);
        }

        // Other validation checks for last name, school name, cousin name, and so on...
        if (!Checkterms.isSelected()) {
            JOptionPane.showMessageDialog(this, "Please accept the Terms & Conditions.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        // Check if the username already exists in the database
        if (userDAO.checkUsernameExists(username)) {
            JOptionPane.showMessageDialog(this, "Username already exists!...Please try to Login", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        return true;
    }

    public void resetForm() {
        txtName.setText("");
        txtSurname.setText("");
        txtEmail.setText("");
        txtDateOfBirth.setText("");
        txtPassword.setText("");
        txtConfirmPassword.setText("");
        txtFirstSchool.setText("");
        txtFirstPet.setText("");
        txtCityBorn.setText("");
        txtOldestCousin.setText("");
        Checkterms.setSelected(false);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnRegister) {
            if (inputValidation()) {
                // Create a User object with the provided details
                User user = new User(txtName.getText(), txtSurname.getText(), txtEmail.getText(),
                        txtDateOfBirth.getText(), new String(txtPassword.getPassword()),
                        txtFirstSchool.getText(), txtFirstPet.getText(), txtCityBorn.getText(),
                        txtOldestCousin.getText());

                // Call the DAO method to save the user to the database
                userDAO.saveUser(user);

                // Show the "Hello" message dialog
                JOptionPane.showMessageDialog(this, "Hello, " + txtName.getText() + " " + txtSurname.getText() + "! Account Registered Successfully.");
                resetForm();
                ApplicantDetailsGUI personalDetailsGUI = new ApplicantDetailsGUI(txtEmail.getText());
                personalDetailsGUI.setP_D_GUI();
                dispose();
            }
        } else if (e.getSource() == btnBack) {
            Login login = new Login();
            login.setLoginGui();
            this.dispose();
        } else if (e.getSource() == btnExit) {
            System.exit(0);
        } else if (e.getSource() == btnClear) {
            // Clear all the text fields and check box
            resetForm();
        }
    }

    public static void main(String[] args) {
        new Register().setRegisterGui();
    }
}
