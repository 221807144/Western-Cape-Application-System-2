/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.cput.varsityapp.domain;

/**
 *
 * @author Asimbonge Mbende(221090754)
 */
public class UploadResultsPOJO {

    private String subjects;
    private int results;
    private int totalAps;
    private String email;

    public UploadResultsPOJO() {
    }

    public UploadResultsPOJO(String subjects) {
        this.subjects = subjects;
    }

    public UploadResultsPOJO(String subjects, int results) {
        this.subjects = subjects;
        this.results = results;
    }

    public UploadResultsPOJO(String email, String subjects, int results) {
        this.email = email;
        this.subjects = subjects;
        this.results = results;
    }

    public int getResults() {
        return results;
    }

    public void setResults(int results) {
        this.results = results;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public UploadResultsPOJO(int totalAps) {
        this.totalAps = totalAps;
    }

    public String getSubjects() {
        return subjects;
    }

    public void setSubjects(String subjects) {
        this.subjects = subjects;
    }

    public int getResults1() {
        return results;
    }

    public void setResults1(int results) {
        this.results = results;
    }

    public int getTotalAps() {
        return totalAps;
    }

    public void setTotalAps(int totalAps) {
        this.totalAps = totalAps;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("UploadResultsPOJO{subjects=").append(subjects);
        sb.append(", results=").append(results);
        sb.append(", totalAps=").append(totalAps);
        sb.append('}');
        return sb.toString();
    }

}
