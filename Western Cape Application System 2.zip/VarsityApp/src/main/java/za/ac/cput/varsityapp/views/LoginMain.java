/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.cput.varsityapp.views;

/**
 *
 * @author Asimbonge Mbende(221090754)
 */
public class LoginMain {

    public static void main(String[] args) {
        new Login().welcomePage();
        
    }

}
