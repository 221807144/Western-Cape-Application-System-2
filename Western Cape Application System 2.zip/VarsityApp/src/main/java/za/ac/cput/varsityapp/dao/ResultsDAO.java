/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.cput.varsityapp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import za.ac.cput.varsityapp.connection.DBConnection;
import za.ac.cput.varsityapp.domain.UploadResultsPOJO;

/**
 *
 * @author user
 */
public class ResultsDAO {

    private Connection conn;
    private PreparedStatement preStmnt;
    private Statement stmnt;

    public ResultsDAO() {
        try {
            this.conn = DBConnection.derbyConnection();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error: Failed to establish database conn" + ex.getMessage());
        }
    }

// public ArrayList<String> getEnrolledSubjects(String email) {
//    ArrayList<String> subjectList = new ArrayList<>();
//    String query = "SELECT Subject FROM Results WHERE Email=?";
//
//    ResultSet rs = null;
//    try {
//        stmnt = this.conn.createStatement();
//         stmnt.setString(1, email);
//        rs = stmnt.executeQuery(query);
//        while (rs.next()) {
//            String subject = rs.getString("Subject");
//            subjectList.add(subject);
//        }
//    } catch (SQLException ex) {
//        JOptionPane.showMessageDialog(null, ex.getMessage(), "Warning", JOptionPane.ERROR_MESSAGE);
//    }
//    return subjectList;
//}
    public List<String> getEnrolledSubjects(String email) {
        List<String> subjectList = new ArrayList<>();
        String query = "SELECT Subject FROM Results WHERE Email = ?";
        ResultSet rs = null;

        try {
            // Prepare the statement
            preStmnt = this.conn.prepareStatement(query);
            preStmnt.setString(1, email);

            // Execute the query
            rs = preStmnt.executeQuery();

            while (rs.next()) {
                String subject = rs.getString("Subject");
                subjectList.add(subject);
            }
        } catch (SQLException ex) {
            ex.printStackTrace(); // Handle the exception properly in your application
        } 
//        finally {
//            // Close the ResultSet, PreparedStatement, and handle exceptions properly
//            if (rs != null) {
//                try {
//                    rs.close();
//                } catch (SQLException e) {
//                    e.printStackTrace();
//                }
//            }
//
//            if (preStmnt != null) {
//                try {
//                    preStmnt.close();
//                } catch (SQLException e) {
//                    e.printStackTrace();
//                }
//            }
//        }
        return subjectList;
    }

    public ArrayList<String> getSubjects() {
        ArrayList<String> subjectList = new ArrayList<>();
        String query = "SELECT Subject FROM Subjects";

        ResultSet rs = null;
        try {
            stmnt = this.conn.createStatement();
            rs = stmnt.executeQuery(query);
            while (rs.next()) {
                String subject = rs.getString("Subject");
                subjectList.add(subject);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Warning", JOptionPane.ERROR_MESSAGE);
        }
        return subjectList;
    }

    public void insertResults(ArrayList<UploadResultsPOJO> resultsList, int totalAps, String email) {
        String insertQuery = "INSERT INTO Results (Email, Subject, Percentage) VALUES (?, ?, ?)";

        try {
            preStmnt = this.conn.prepareStatement(insertQuery);
            for (UploadResultsPOJO result : resultsList) {
                preStmnt.setString(1, email);
                preStmnt.setString(2, result.getSubjects());
                preStmnt.setInt(3, result.getResults1());
                preStmnt.executeUpdate();
            }

            // Insert total APS into a separate table
            String insTotalApsQuery = "INSERT INTO TotalAps (Email, Total_App_Score) VALUES (?, ?)";
            try {
                preStmnt = this.conn.prepareStatement(insTotalApsQuery);
                preStmnt.setString(1, email);
                preStmnt.setInt(2, totalAps);
                preStmnt.executeUpdate();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, e.getMessage(), "Warning", JOptionPane.ERROR_MESSAGE);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage(), "Warning", JOptionPane.ERROR_MESSAGE);
        }
    }
//    public void insertResults(ArrayList<UploadResultsPOJO> resultsList, int totalAps) {
//        String insertQuery = "INSERT INTO Results (Subject, Percentage) VALUES (?, ?)";
//
//        try {
//            preStmnt = this.conn.prepareStatement(insertQuery);
//            for (UploadResultsPOJO result : resultsList) {
//                preStmnt.setString(1, result.getSubjects());
//                preStmnt.setInt(2, result.getResults1());
//                preStmnt.executeUpdate();
//            }
//
//            // Insert total APS into a separate table
//            String insTotalApsQuery = "INSERT INTO TotalAps (Total_App_Score) VALUES (?)";
//            try {
//                preStmnt = this.conn.prepareStatement(insTotalApsQuery);
//                preStmnt.setInt(1, totalAps);
//                preStmnt.executeUpdate();
//            } catch (SQLException e) {
//                JOptionPane.showMessageDialog(null, e.getMessage(), "Warning", JOptionPane.ERROR_MESSAGE);
//            }
//
//        } catch (SQLException e) {
//            JOptionPane.showMessageDialog(null, e.getMessage(), "Warning", JOptionPane.ERROR_MESSAGE);
//        }
//    }

    public boolean deleteResults(String subject, String email) {
        try {
            String sql = "DELETE FROM Results WHERE Email = ? AND Subject = ?  ";
            preStmnt = this.conn.prepareStatement(sql);
            preStmnt.setString(1, subject);
            preStmnt.setString(2, email);
            int rowsAffected = preStmnt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }

    public UploadResultsPOJO getStudSubject(String email, String subject) {
        try {
            String sql = "SELECT * FROM Results WHERE Email = ? AND Subject = ?";
            preStmnt = this.conn.prepareStatement(sql);
            preStmnt.setString(1, email);
            preStmnt.setString(2, subject);
            ResultSet rs = preStmnt.executeQuery();

            if (rs.next()) {
                int percentage = rs.getInt("Percentage");
                return new UploadResultsPOJO(subject, percentage);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

        return null;
    }

// 24 October 16:35
//public UploadResultsPOJO getStudSubject(String email, String subject) {
//    try {
//        String sql = "SELECT Subject FROM Results WHERE Email = ? AND Subject = ?";
//        preStmnt = this.conn.prepareStatement(sql);
//        preStmnt.setString(1, email);
//        preStmnt.setString(2, subject);
//        ResultSet rs = preStmnt.executeQuery();
//
//        if (rs.next()) {
//            int percentage = rs.getInt("Percentage");
//            return new UploadResultsPOJO(subject, percentage);
//        }
//    } catch (SQLException ex) {
//        JOptionPane.showMessageDialog(null, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
//    }
//
//    return null;
//}
//    public UploadResultsPOJO getStudSubject(String subject) {
//
//        try {
//            String sql = "SELECT * FROM Results WHERE Email=? AND Subject = ?";
//            preStmnt = this.conn.prepareStatement(sql);
//            preStmnt.setString(1, subject);
//            ResultSet rs = preStmnt.executeQuery();
//
//            if (rs.next()) {
//                int percentage = rs.getInt("Percentage");
//
//                return new UploadResultsPOJO(subject, percentage);
//            }
//        } catch (SQLException ex) {
//            JOptionPane.showMessageDialog(null, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
//        }
//
//        return null;
//    }
    public ArrayList<String> getSubjectList() {
        ArrayList<String> subjectList = new ArrayList<>();
        String query = "SELECT Subject FROM Subjects";

        ResultSet rs = null;
        try {
            stmnt = this.conn.createStatement();
            rs = stmnt.executeQuery(query);
            while (rs.next()) {
                String subject = rs.getString("Subject");
                subjectList.add(subject);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Warning", JOptionPane.ERROR_MESSAGE);
        }
        return subjectList;
    }

    public boolean updateResults(UploadResultsPOJO results) {
        String query = "UPDATE Results SET Percentage = ? WHERE  Email = ? AND Subject = ? ";

        try {
            preStmnt = this.conn.prepareStatement(query);
            preStmnt.setInt(1, results.getResults1());
            preStmnt.setString(2, results.getEmail()); 
            preStmnt.setString(3, results.getSubjects()); 

            int rowsAffected = preStmnt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException ex) {
            ex.printStackTrace(); // Print the exception for debugging purposes
            return false;

//            JOptionPane.showMessageDialog(null, ex.getMessage(), "Warning", JOptionPane.ERROR_MESSAGE);
//            return false;
        }
    }

// 24 October 17:22
//    public boolean updateResults(UploadResultsPOJO results) {
//        String query = "UPDATE Results SET Percentage = ? WHERE Subject = ? AND Email=?";
//        try {
//            preStmnt = this.conn.prepareStatement(query);
//            preStmnt.setInt(1, results.getResults1());
//            preStmnt.setString(2, results.getSubjects());
//
//            int rowsAffected = preStmnt.executeUpdate();
//            return rowsAffected > 0;
//        } catch (SQLException ex) { // Print the full stack trace
//
//            JOptionPane.showMessageDialog(null, ex.getMessage(), "Warning", JOptionPane.ERROR_MESSAGE);
//            return false;
//        }
//    }
    public void updateTotalAps(int newTotalAps, String email) {
        String updateQuery = "UPDATE TotalAps SET Total_App_Score = ? WHERE Email = ?";

        try {
            preStmnt = conn.prepareStatement(updateQuery);
            preStmnt.setInt(1, newTotalAps);
            preStmnt.setString(2, email);

            preStmnt.executeUpdate();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Warning", JOptionPane.ERROR_MESSAGE);
        }
    }

//  24 Octobeer 17:22
//    public void updateTotalAps(int newTotalAps) {
//        String updateQuery = "UPDATE TotalAps SET Total_App_Score = ? WHERE AND Email=?";
//
//        try {
//            preStmnt = conn.prepareStatement(updateQuery);
//            preStmnt.setInt(1, newTotalAps);
//            preStmnt.executeUpdate();
//        } catch (SQLException ex) {
//            JOptionPane.showMessageDialog(null, ex.getMessage(), "Warning", JOptionPane.ERROR_MESSAGE);
//        }
//    }
    public ArrayList<UploadResultsPOJO> getRemainingResults(String email, String selectedSubject) {
        ArrayList<UploadResultsPOJO> remainingResults = new ArrayList<>();

        String query = "SELECT Subject, Percentage FROM Results WHERE Email = ? AND Subject != ?  ";

        try {
            preStmnt = conn.prepareStatement(query);
            preStmnt.setString(1, email);
            preStmnt.setString(2, selectedSubject);

            ResultSet rs = preStmnt.executeQuery();

            while (rs.next()) {
                String subject = rs.getString("Subject");
                int percentage = rs.getInt("Percentage");
                remainingResults.add(new UploadResultsPOJO(subject, percentage));
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

        return remainingResults;
    }

//  24 October 17:06
//    public ArrayList<UploadResultsPOJO> getRemainingResults(String selectedSubject) {
//        ArrayList<UploadResultsPOJO> remainingResults = new ArrayList<>();
//
//        String query = "SELECT Subject, Percentage FROM Results WHERE subject != ? AND Email=? ";
//
//        try {
//            preStmnt = conn.prepareStatement(query);
//            preStmnt.setString(1, selectedSubject);
//            ResultSet rs = preStmnt.executeQuery();
//
//            while (rs.next()) {
//                String subject = rs.getString("Subject");
//                int percentage = rs.getInt("Percentage");
//                remainingResults.add(new UploadResultsPOJO(subject, percentage));
//            }
//        } catch (SQLException ex) {
//            JOptionPane.showMessageDialog(null, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
//        }
//
//        return remainingResults;
//    }
}
