/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.cput.varsityapp.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author user
 */
public class DBConnection {

    public static Connection derbyConnection() throws SQLException {
        String dbURL = "jdbc:derby://localhost:1527/VarsityDB";
        String dbUsername = "administrator";
        String dbPassword = "password";
        Connection conn = DriverManager.getConnection(dbURL, dbUsername, dbPassword);
        return conn;

    }
}
