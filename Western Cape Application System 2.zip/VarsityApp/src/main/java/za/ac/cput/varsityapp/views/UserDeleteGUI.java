/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package za.ac.cput.varsityapp.views;

/**
 *
 * @author Skhoma
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import za.ac.cput.varsityapp.dao.UserDAO;

public class UserDeleteGUI extends JFrame {

    private JTextField usernameField;
    private JButton deleteButton, cancelButton;
    private JPasswordField passwordField;
    private UserDAO userDAO;
    private Font font1, font2, font3;

    public UserDeleteGUI() {

        setTitle("User Delete");
        userDAO = new UserDAO();
        font1 = new Font("Times New Roman", Font.BOLD, 28);
        font2 = new Font("Times New Roman", Font.ITALIC, 22);
        font3 = new Font("Arial", Font.BOLD, 15);
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(3, 2));

        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setFont(font3);
        usernameField = new JTextField();
        usernameField.setFont(font3);

        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setFont(font3);
        passwordField = new JPasswordField();
        passwordField.setFont(font3);

        deleteButton = new JButton("Delete");
        deleteButton.setFont(font2);
        cancelButton = new JButton("Cancel");
        cancelButton.setFont(font2);

        panel.add(usernameLabel);
        panel.add(usernameField);
        panel.add(passwordLabel);
        panel.add(passwordField);
        panel.add(deleteButton);
        panel.add(cancelButton);

        add(panel);

        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                char[] passwordChars = passwordField.getPassword();
                String password = new String(passwordChars);

                if (!username.isEmpty() && passwordChars.length > 0) {
                    // Validate user's credentials
                    if (validateUserCredentials(username, password)) {
                        // Delete the user
                        deleteUser(username);
                        JOptionPane.showMessageDialog(null, "User deleted successful");
                    } else {
                        JOptionPane.showMessageDialog(UserDeleteGUI.this,
                                "Invalid username or password.",
                                "Error",
                                JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(UserDeleteGUI.this,
                            "Please enter both username and password.",
                            "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
    }

    public boolean validateUserCredentials(String username, String password) {
        return userDAO.login(username, password);
    }

    public void deleteUser(String username) {
        userDAO.deleteUser(username);
    }

    public void setUserDeleteGUI() {
        setSize(300, 150);
        setLocationRelativeTo(null);
        setVisible(true);
        setResizable(false);
    }

    public static void main(String[] args) {
        new UserDeleteGUI().setUserDeleteGUI();
    }
}
