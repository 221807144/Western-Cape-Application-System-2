/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.cput.varsityapp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import za.ac.cput.varsityapp.connection.DBConnection;
import za.ac.cput.varsityapp.domain.N_O_K_DetailsPOJO;

/**
 *
 * @author user
 */
public class N_O_K_DetailsDAO {

    private Connection conn;
    private PreparedStatement preStmnt;
    private Statement stmnt;

    public N_O_K_DetailsDAO() {
        try {
            this.conn = DBConnection.derbyConnection();
            this.preStmnt = null; // Initialize the PreparedStatement
            this.stmnt = null;    // Initialize the Statement
        } catch (SQLException ex) {
            System.out.println("Error: Failed to establish database conn" + ex.getMessage());
        }
    }

//    public N_O_K_DetailsPOJO save(N_O_K_DetailsPOJO nok) {
//        int rowsAffected;
//        String query = "INSERT INTO NextOfKinDetails (Student_Email, Title, FirstName, LastName, Gender, Email, CellNumber, Address) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
//        try {
//            preStmnt = this.conn.prepareStatement(query);
//            preStmnt.setString(1, nok.getStudentEmail());
//            preStmnt.setString(2, nok.getTitle());
//            preStmnt.setString(3, nok.getFirstName());
//            preStmnt.setString(4, nok.getLastName());
//            preStmnt.setString(5, nok.getGender());
//            preStmnt.setString(6, nok.getEmail());
//            preStmnt.setString(7, nok.getCellNo());
//            preStmnt.setString(8, nok.getAddress());
//
//            rowsAffected = preStmnt.executeUpdate();
//            if (rowsAffected > 0) {
//                JOptionPane.showMessageDialog(null, "Success: Next of Kin's Information saved");
//            } else {
//                JOptionPane.showMessageDialog(null, "Error: Next of Kin's Information could not be saved");
//            }
//        } catch (SQLException sqlException) {
//            JOptionPane.showMessageDialog(null, "Error: " + sqlException.getMessage());
//        } finally {
//            try {
//                if (preStmnt != null) {
//                    preStmnt.close();
//                }
//            } catch (SQLException exception) {
//                JOptionPane.showMessageDialog(null, exception.getMessage(), "Warning", JOptionPane.ERROR_MESSAGE);
//            }
//        }
//
//        return nok;
//    }
    public N_O_K_DetailsPOJO save(N_O_K_DetailsPOJO nok) {

        int ok;

        try {
            stmnt = this.conn.createStatement();
            ok = stmnt.executeUpdate("INSERT INTO NextOfKinDetails VALUES('" + nok.getStudentEmail() + "','"
                    + nok.getTitle() + "','"
                    + nok.getFirstName() + "','"
                    + nok.getLastName() + "','"
                    + nok.getGender() + "','"
                    + nok.getEmail() + "','"
                    + nok.getCellNo() + "','"
                    + nok.getAddress() + "')");
            if (ok > 0) {
                System.out.println("Success: Next of Kin's Information saved");
//                JOptionPane.showMessageDialog(null, "Success: Next of Kin's Information saved");

            } else {
                 System.out.println("Error : Next of Kin's Information could not be saved");
//                JOptionPane.showMessageDialog(null, "Error : Next of Kin's Information could not be saved");

            }

        } catch (SQLException sqlException) {
            sqlException.printStackTrace();

        } catch (Exception e) {
             e.printStackTrace();

        } finally {
            // Close the Statement and PreparedStatement in a finally block
            try {
                if (stmnt != null) {
                    stmnt.close();
                }
            } catch (SQLException ex) {
                // Handle the exception or log it as needed
                ex.printStackTrace();
            }
        }
        return nok;
    }

 public boolean deleteStudent(String studentEmail, String student) {
    try {
        String sql = "DELETE FROM NextOfKinDetails WHERE Email = ? AND Student_Email = ?";
        preStmnt = this.conn.prepareStatement(sql);
        preStmnt.setString(1, studentEmail);
        preStmnt.setString(2, student);
        int rowsAffected = preStmnt.executeUpdate();
        return rowsAffected > 0;
    } catch (SQLException ex) {
         ex.printStackTrace();
        return false;
    } finally {
        try {
            if (preStmnt != null) {
                preStmnt.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace(); // Log or handle the exception
        }
    }
}


//    public boolean deleteStudent(String student) {
//
//        try {
//            String sql = "DELETE FROM NextOfKinDetails WHERE Email = ? AND Student_Email=?";
//            preStmnt = this.conn.prepareStatement(sql);
//            preStmnt.setString(1, student);
//            int rowsAffected = preStmnt.executeUpdate();
//            return rowsAffected > 0;
//        } catch (SQLException ex) {
//            JOptionPane.showMessageDialog(null, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
//            return false;
//        }
//
//    }
public N_O_K_DetailsPOJO getStudEmail(String studentEmail, String email) {
    ResultSet rs = null;
    try {
        String sql = "SELECT * FROM NextOfKinDetails WHERE Email = ? AND Student_Email=?";
        preStmnt = this.conn.prepareStatement(sql);
        preStmnt.setString(1, email);
        preStmnt.setString(2, studentEmail); // Set the studentEmail parameter
        rs = preStmnt.executeQuery();

        if (rs.next()) {
            String studEmail = rs.getString("Student_Email");
            String title = rs.getString("Title");
            String firstName = rs.getString("FirstName");
            String lastName = rs.getString("LastName");
            String gender = rs.getString("Gender");
            String CellNo = rs.getString("CellNumber");
            String address = rs.getString("Address");
            return new N_O_K_DetailsPOJO(studEmail, title, firstName, lastName, gender, email, CellNo, address);
        }
    } catch (SQLException ex) {
        ex.printStackTrace();
    } finally {
        try {
            if (rs != null) {
                rs.close();
            }
            if (preStmnt != null) {
                preStmnt.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace(); // Log or handle the exception
        }
    }

    return null;
}



//    public ArrayList<String> getEmails() {
//        ArrayList<String> emailList = new ArrayList<>();
//        String query = "SELECT Email FROM NextOfKinDetails WHERE Student_Email=?";
//
//        ResultSet rs = null;
//        try {
//            stmnt = this.conn.createStatement();
//            rs = stmnt.executeQuery(query);
//            while (rs.next()) {
//                String email = rs.getString("Student_Email");
//                emailList.add(email);
//            }
//        } catch (SQLException ex) {
//             ex.printStackTrace();
//        } finally {
//            // Close the Statement and PreparedStatement in a finally block
//            try {
//                if (rs != null) {
//                    rs.close();
//                }
//                if (stmnt != null) {
//                    stmnt.close();
//                }
//            } catch (SQLException ex) {
//                // Handle the exception or log it as needed
//                ex.printStackTrace();
//            }
//        }
//        return emailList;
//    }
public ArrayList<String> getEmails(String studentEmail) {
    ArrayList<String> emailList = new ArrayList<>();
    String query = "SELECT Email FROM NextOfKinDetails WHERE Student_Email=?";
    ResultSet rs = null;

    try {
        preStmnt = this.conn.prepareStatement(query); // Use PreparedStatement here
        preStmnt.setString(1, studentEmail); // Set the parameter value

        rs = preStmnt.executeQuery();

        while (rs.next()) {
            String email = rs.getString("Email");
            emailList.add(email);
        }
    } catch (SQLException ex) {
        ex.printStackTrace();
    } finally {
        // Close the Statement and PreparedStatement in a finally block
        try {
            if (rs != null) {
                rs.close();
            }
            if (preStmnt != null) {
                preStmnt.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    return emailList;
}

    public boolean updateNOK(N_O_K_DetailsPOJO student) {
        String query = "UPDATE NextOfKinDetails SET Title = ?, FirstName = ?, LastName = ?,Gender = ?,CellNumber = ?,Address = ? WHERE Email = ?";
        try {
            preStmnt = this.conn.prepareStatement(query);
            preStmnt.setString(1, student.getTitle());
            preStmnt.setString(2, student.getFirstName());
            preStmnt.setString(3, student.getLastName());
            preStmnt.setString(4, student.getGender());
            preStmnt.setString(5, student.getCellNo());
            preStmnt.setString(6, student.getAddress());
            preStmnt.setString(7, student.getEmail());
            int rowsAffected = preStmnt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException ex) {
            ex.printStackTrace();  // Print the full stack trace
//            JOptionPane.showMessageDialog(null, ex.getMessage(), "Warning", JOptionPane.ERROR_MESSAGE);
            return false;
        } finally {
            // Close the Statement and PreparedStatement in a finally block
            try {
                if (preStmnt != null) {
                    preStmnt.close();
                }
            } catch (SQLException ex) {
                // Handle the exception or log it as needed
                ex.printStackTrace();
            }
        }
    }
}
