package za.ac.cput.varsityapp.views;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.table.*;
import za.ac.cput.varsityapp.dao.CourseFeeDAO;

/**
 *
 * @author
 */
public class CourseFeeGUI extends JFrame implements ActionListener, ItemListener {

    DefaultTableModel tableModel_1, tableModel_2;
    private JPanel panelNorth, panelCentre, panelEast, panelSouth;
    private JLabel lblHeading, lblBursaries_And_Fees;
    private JComboBox cboFilter;
    private JButton btnBack, btnShowCourses, btnNext;
    private JTable table1, table2;
    private Font font1, font2, font3;
    private CourseFeeDAO courseFeeDAO;
    private String studentEmail;

    public CourseFeeGUI(String email) {
        super("Courses,Bursaries available and Fees");
        //Changes the default java logo
        try {
            BufferedImage customIconImage = ImageIO.read(new File("Logo2.jpg"));
            // Set the custom icon for the JFrame
            setIconImage(customIconImage);
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        this.studentEmail=email;
        panelNorth = new JPanel();
        panelNorth.setBackground(new Color(15, 194, 252));
        panelEast = new JPanel();
        panelCentre = new JPanel();
        panelCentre.setBackground(new Color(15, 194, 252));
        panelSouth = new JPanel();
        courseFeeDAO = new CourseFeeDAO();
        font1 = new Font("Times New Roman", Font.BOLD, 28);
        font2 = new Font("Times New Roman", Font.ITALIC, 22);
        font3 = new Font("Arial", Font.BOLD, 15);
        lblHeading = new JLabel("Courses selected:");
        lblHeading.setHorizontalAlignment(SwingConstants.CENTER);
        lblHeading.setFont(font1);
        tableModel_1 = new DefaultTableModel();
        table1 = new JTable(tableModel_1);
        tableModel_1.addColumn("Course");
        tableModel_1.addColumn("Institution");
        tableModel_1.addColumn("Course Fee");

        lblBursaries_And_Fees = new JLabel("Bursaries Available ");
        lblBursaries_And_Fees.setHorizontalAlignment(SwingConstants.CENTER);
        lblBursaries_And_Fees.setFont(font1);
        cboFilter = new JComboBox(new String[]{"NSFAS", "Fundi", "Nedbank", "Fedisa Bursary", "The Ivestec Bursary", "None"});
        cboFilter.setSelectedIndex(5);
        cboFilter.setSize(30, 5);

        tableModel_2 = new DefaultTableModel();
        table2 = new JTable(tableModel_2);
        tableModel_2.addColumn("Course");
        tableModel_2.addColumn("Bursary");
        courseFeeDAO.retrieveBursaries(tableModel_2);

        btnBack = new JButton("Back");
        btnBack.setBackground(Color.red);

        btnShowCourses = new JButton("Show Courses");
        btnShowCourses.setBackground(Color.GRAY);

        btnNext = new JButton("Next");
        btnNext.setBackground(new Color(39, 214, 53));

        cboFilter.addItemListener(this);
        btnBack.addActionListener(this);
        btnShowCourses.addActionListener(this);
        btnNext.addActionListener(this);

    }

    public void setCourseFeeGUI() {
        panelNorth.setLayout(new GridLayout(2, 1));
        panelEast.setLayout(new GridLayout(1, 1));
        panelCentre.setLayout(new GridLayout(4, 1));
        panelSouth.setLayout(new GridLayout(1, 3));

        panelNorth.add(lblHeading);

        table1.setModel(tableModel_1);
        JScrollPane scrollPane1 = new JScrollPane(table1);
        panelCentre.add(scrollPane1);

        panelCentre.add(lblBursaries_And_Fees);
        //panelCentre.add(cboFilter);
        panelEast.add(cboFilter);
        table2.setModel(tableModel_2);
        JScrollPane scrollPane2 = new JScrollPane(table2);
        panelCentre.add(scrollPane2);

        panelSouth.add(btnBack);
        btnBack.setFont(font2);

        panelSouth.add(btnShowCourses);
        btnShowCourses.setFont(font2);

        panelSouth.add(btnNext);
        btnNext.setFont(font2);

        this.add(panelNorth, BorderLayout.NORTH);
        this.add(panelEast, BorderLayout.EAST);
        this.add(panelCentre, BorderLayout.CENTER);
        this.add(panelSouth, BorderLayout.SOUTH);

        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(900, 500);
        this.setLocationRelativeTo(null);
        this.setVisible(true);
    }

    private void bursaryFilter(String bursaryQuery) {
        TableRowSorter<DefaultTableModel> bursaSorter = new TableRowSorter<DefaultTableModel>(tableModel_2);
        table2.setRowSorter(bursaSorter);
        if (!bursaryQuery.equals("None")) {
            bursaSorter.setRowFilter(RowFilter.regexFilter(bursaryQuery));
        } else {
            table2.setRowSorter(bursaSorter);
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnBack) {
            CourseSelectionGUI courseSelectionGUI = new CourseSelectionGUI(studentEmail);
            courseSelectionGUI.setC_S_GUI();
            dispose();
        } else if (e.getSource() == btnShowCourses) {
//           courseFeeDAO.retrieveCourses(tableModel_1);
           courseFeeDAO.retrieveCourses(tableModel_1, studentEmail);

        } else if (e.getSource() == btnNext) {
            LastPage lastPage = new LastPage(studentEmail);
//            lastPage.setL_P_GUI();
            dispose();

        }
    }

    @Override
    public void itemStateChanged(ItemEvent e) {
        String query = cboFilter.getSelectedItem().toString();
        bursaryFilter(query);
    }
}
