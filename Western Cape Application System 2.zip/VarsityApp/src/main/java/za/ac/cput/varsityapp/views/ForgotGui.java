/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package za.ac.cput.varsityapp.views;

/**
 *
 * @author Skhoma
 */
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;
import za.ac.cput.varsityapp.dao.UserDAO;
import za.ac.cput.varsityapp.domain.User;

public class ForgotGui extends JFrame implements ActionListener {

    private JLabel lblLogo, lblHeading, lblSecurityQuestions, lblFirstSchool, lblFirstPet, lblCityBorn, lblOldestCousin;
    private JPanel panelNorth, panelSouth, panelEast, panelCenter;
    private JTextField txtUsername, txtFirstSchool, txtFirstPet, txtCityBorn, txtOldestCousin;
    private JCheckBox Checkterms;
    private JButton btnGetPassword, btnLogin, btnClear, btnExit, btnDeleteAccount, btnUpdatePassword;
    private UserDAO userDAO;
    private DefaultTableModel tableModel;
    JTable tblLogins;
    ArrayList<User> subjectList = new ArrayList<>();
    private Font font1, font2, font3;

    public ForgotGui() {
        super("Forgot Password");
        userDAO = new UserDAO();
        font1 = new Font("Times New Roman", Font.BOLD, 28);
        font2 = new Font("Times New Roman", Font.ITALIC, 15);
        font3 = new Font("Arial", Font.BOLD, 15);
        ImageIcon imageIcon = new ImageIcon("./PRMLogo.png");
        Image image = imageIcon.getImage();
        Image newimg = image.getScaledInstance(250, 150, java.awt.Image.SCALE_SMOOTH);
        imageIcon = new ImageIcon(newimg);
        lblLogo = new JLabel("", imageIcon, SwingConstants.LEFT);
        lblHeading = new JLabel("Forgot password");
        lblHeading.setFont(font1);
        txtUsername = new JTextField(20);
        setPlaceholder(txtUsername, "Enter Username", Color.GRAY);

        txtFirstSchool = new JTextField(20);
        setPlaceholder(txtFirstSchool, "name of the first school you attending", Color.GRAY);
        //setPlaceholder(txtFirstSchool, "Enter First School", Color.GRAY);

        txtFirstPet = new JTextField(20);
        setPlaceholder(txtFirstPet, "Enter your first pet's name ", Color.GRAY);
        // setPlaceholder(txtFirstPet, "Enter First Pet", Color.GRAY);

        txtCityBorn = new JTextField(20);
        setPlaceholder(txtCityBorn, "Enter the name of the city you were born", Color.GRAY);
        //setPlaceholder(txtCityBorn, "Enter City Born", Color.GRAY);

        txtOldestCousin = new JTextField(20);
        setPlaceholder(txtOldestCousin, "Enter the name of your oldest cousin", Color.GRAY);
        //  setPlaceholder(txtOldestCousin, "Enter Oldest Cousin", Color.GRAY);

        lblFirstSchool = new JLabel("What was the name of the first school you attending?");
        lblFirstSchool.setFont(font2);
        lblFirstPet = new JLabel("What was your first pet's name?");
        lblFirstPet.setFont(font2);
        lblCityBorn = new JLabel("what's the name of the city you were born?");
        lblCityBorn.setFont(font2);
        lblOldestCousin = new JLabel("What is the name of your oldest cousin?");
        lblOldestCousin.setFont(font2);
        lblSecurityQuestions = new JLabel("Enter security questions," + "\n And we’ll help you get your password.");
        lblSecurityQuestions.setFont(font2);

        btnGetPassword = new JButton("Get Password");
        btnGetPassword.setFont(font2);
        btnLogin = new JButton("Login");
        btnLogin.setFont(font2);
        btnClear = new JButton("Clear");
        btnClear.setFont(font2);
        btnExit = new JButton("Exit");
        btnExit.setFont(font2);
        btnDeleteAccount = new JButton("Delete Account");
        btnDeleteAccount.setFont(font2);
        btnUpdatePassword = new JButton("Update Password");
        btnUpdatePassword.setFont(font2);

        panelNorth = new JPanel();
        panelCenter = new JPanel();
        panelEast = new JPanel();
        panelSouth = new JPanel();

        panelNorth.add(lblLogo);
        panelNorth.add(lblHeading);
        panelNorth.setLayout(new FlowLayout());
        panelCenter.setLayout(new GridLayout(6, 1));
        panelSouth.setLayout(new GridLayout(1, 6));

        panelCenter.add(lblSecurityQuestions);

        panelCenter.add(txtUsername);
        panelCenter.add(txtFirstSchool);
        panelCenter.add(txtFirstPet);
        panelCenter.add(txtCityBorn);
        panelCenter.add(txtOldestCousin);

        tableModel = new DefaultTableModel();
        tblLogins = new JTable(tableModel);
        panelEast.add(new JScrollPane(tblLogins));

        tableModel.addColumn("UserName");
        tableModel.addColumn("Password");

        panelSouth.add(btnGetPassword);
        panelSouth.add(btnLogin);
        panelSouth.add(btnClear);
        panelSouth.add(btnExit);
        panelSouth.add(btnUpdatePassword);
        panelSouth.add(btnDeleteAccount);
    }

    // Method to set placeholder text and color for a JTextField
    private void setPlaceholder(JTextField textField, String placeholder, Color placeholderColor) {
        textField.setText(placeholder);
        textField.setForeground(placeholderColor);

        textField.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {
                if (textField.getText().equals(placeholder)) {
                    textField.setText("");
                    textField.setForeground(Color.BLACK);
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if (textField.getText().isEmpty()) {
                    textField.setText(placeholder);
                    textField.setForeground(placeholderColor);
                }
            }
        });
    }

    public void setGuiForgotPass() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(900, 600);
        setLocationRelativeTo(null);
        this.setVisible(true);
        this.add(panelNorth, BorderLayout.NORTH);
        this.add(panelCenter, BorderLayout.CENTER);
        this.add(panelEast, BorderLayout.EAST);
        this.add(panelSouth, BorderLayout.SOUTH);

        // Add the ActionListener to the btnRegister button
        btnGetPassword.addActionListener(this);
        btnLogin.addActionListener(this);
        btnClear.addActionListener(this);
        btnExit.addActionListener(this);
        btnUpdatePassword.addActionListener(this);
        btnDeleteAccount.addActionListener(this);

        btnGetPassword.setBackground(Color.PINK);
        btnLogin.setBackground(Color.GREEN);
        btnClear.setBackground(Color.GRAY);
        btnExit.setBackground(Color.RED);
        btnUpdatePassword.setBackground(Color.ORANGE); // Example color, you can adjust as needed
//        btnDeleteAccount.setBackground(Color.BLUE); // 

        panelNorth.setBackground(new Color(15, 194, 252));
        panelCenter.setBackground(new Color(15, 194, 252));
        panelEast.setBackground(new Color(15, 194, 252));
        panelSouth.setBackground(new Color(15, 194, 252));
        this.getContentPane().setBackground(new Color(15, 194, 252));
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnGetPassword) {
            String username = txtUsername.getText();
            String firstSchool = txtFirstSchool.getText();
            String firstPet = txtFirstPet.getText();
            String cityBorn = txtCityBorn.getText();
            String oldestCousin = txtOldestCousin.getText();

            // Check if the user exists in the database
            if (userDAO.checkUserExistence(username, firstSchool, firstPet, cityBorn, oldestCousin)) {
                // If the user exists, retrieve the user from the database
                User user = userDAO.getUserByUsername(username);

                if (user != null) {
                    // Add the user data to the table model
                    tableModel.addRow(new Object[]{user.getUsername(), user.getPassword()});
                }
            } else {
                // If the user does not exist, show an error message
                JOptionPane.showMessageDialog(this, "User does not exist in the database.");
            }
        } else if (e.getSource() == btnLogin) {
            Login log = new Login();
            log.setLoginGui();
        } else if (e.getSource() == btnClear) {
            // Clear all the text fields
            txtUsername.setText("");
            txtFirstSchool.setText("");
            txtFirstPet.setText("");
            txtCityBorn.setText("");
            txtOldestCousin.setText("");

            // ... Clear any other text fields ...
// Reset the placeholder texts and their colors
            setPlaceholder(txtUsername, "Enter Username", Color.GRAY);
            setPlaceholder(txtFirstSchool, "Name of the first school you attending", Color.GRAY);
            setPlaceholder(txtFirstPet, "Enter your first pet's name", Color.GRAY);
            setPlaceholder(txtCityBorn, "Enter the name of the city you were born", Color.GRAY);
            setPlaceholder(txtOldestCousin, "Enter the name of your oldest cousin", Color.GRAY);

            // Uncheck the terms checkbox
            Checkterms.setSelected(false);
        } else if (e.getSource() == btnExit) {
            System.exit(0);
        } else if (e.getSource() == btnDeleteAccount) {

            UserDeleteGUI userDelete = new UserDeleteGUI();
            userDelete.setUserDeleteGUI();

        } else if (e.getSource() == btnUpdatePassword) {
            PasswordUpdateGUI passGui = new PasswordUpdateGUI();
            passGui.setPasswordUpdateGUI();
        }
    }

}
