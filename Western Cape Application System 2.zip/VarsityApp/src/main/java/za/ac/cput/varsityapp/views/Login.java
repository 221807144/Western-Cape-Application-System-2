/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package za.ac.cput.varsityapp.views;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.Timer;
import za.ac.cput.varsityapp.dao.UserDAO;
//import za.ac.cput.jdbcloginprac2.dao.UserDAO;

/**
 *
 * @author Mzie
 */
public class Login extends JFrame implements ActionListener {

    private JPanel panelNorth, panelCenter, panelSouth, gifPanel;
    private JLabel lblEmail, lblPassword, lblHeading, gifLabel, lblLogo;
    private JTextField txtEmail;
    private JPasswordField txtPassword;
    private JButton btnLogin, btnExit, btnRegister, btnCForgotPassword;
    private Font font1, font2, font3;

    public Login() {
        super("Login");
        ImageIcon imageIcon = new ImageIcon("./PRMLogo.png");
        Image image = imageIcon.getImage();
        Image newimg = image.getScaledInstance(250, 150, java.awt.Image.SCALE_SMOOTH);
        imageIcon = new ImageIcon(newimg);
        font1 = new Font("Times New Roman", Font.BOLD, 28);
        font2 = new Font("Times New Roman", Font.ITALIC, 22);
        font3 = new Font("Arial", Font.BOLD, 15);

        lblHeading = new JLabel("Login", imageIcon, SwingConstants.CENTER);
        lblHeading.setFont(font1);
        //lblHeading.setForeground(Color.YELLOW);
        //Changes the default java logo
        try {
            BufferedImage customIconImage = ImageIO.read(new File("Logo2.jpg"));
            // Set the custom icon for the JFrame
            setIconImage(customIconImage);
        } catch (IOException ex) {
            // Handle any errors while loading the image (optional)
            ex.printStackTrace();
        }

        //lblLogo = new JLabel(new ImageIcon("Logo.jpg"));//this one makes the image to take a lot of space on the north panel
        //To set the size of the image so that it does not take a lot of space on the north panel
        try {
            BufferedImage img = ImageIO.read(new File("Logo2.jpg"));
            Image scaledImg = img.getScaledInstance(400, 180, Image.SCALE_SMOOTH);
            ImageIcon icon = new ImageIcon(scaledImg);
            lblLogo = new JLabel(icon);
        } catch (IOException ex) {
            lblLogo = new JLabel("Logo not found");
        }
        panelNorth = new JPanel();
        panelCenter = new JPanel();
        panelSouth = new JPanel();
        lblEmail = new JLabel("Email:");
        lblEmail.setFont(font3);
        lblPassword = new JLabel("Password:");
        lblPassword.setFont(font3);
        txtEmail = new JTextField(65);
        txtEmail.setFont(font3);
        txtPassword = new JPasswordField(35);
        txtPassword.setFont(font3);
        btnLogin = new JButton("Login");
        btnLogin.setFont(font2);
        btnExit = new JButton("Exit");
        btnExit.setFont(font2);

        btnRegister = new JButton("Register");
        btnRegister.setFont(font2);
        btnCForgotPassword = new JButton("Forgot Password");
        btnCForgotPassword.setFont(font2);

        panelCenter.add(lblEmail);
        panelCenter.add(txtEmail);
        panelCenter.add(lblPassword);
        panelCenter.add(txtPassword);
        panelSouth.add(btnLogin);
        panelSouth.add(btnRegister);

        panelSouth.add(btnCForgotPassword);
        panelSouth.add(btnExit);

        btnLogin.setBackground(Color.GREEN);
        btnCForgotPassword.setBackground(Color.GRAY);
        btnRegister.setBackground(Color.PINK);
        btnExit.setBackground(Color.RED);

        panelNorth.add(lblHeading);
        btnLogin.addActionListener(this);
        btnExit.addActionListener(this);
        btnRegister.addActionListener(this);
        btnCForgotPassword.addActionListener(this);

        panelCenter.setLayout(new GridLayout(2, 2));
        panelNorth.setLayout(new FlowLayout());
        panelSouth.setLayout(new GridLayout(1, 4));

        panelNorth.setBackground(new Color(15, 194, 252));
        panelCenter.setBackground(new Color(15, 194, 252));

        panelSouth.setBackground(new Color(15, 194, 252));
        this.getContentPane().setBackground(new Color(15, 194, 252));
    }
//**************************************Welcom*****************************************

    public void welcomePage() {
        setTitle("Welcome to Central Application Office");
        setPreferredSize(new Dimension(1000, 400));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        gifPanel = new JPanel(new BorderLayout());
        ImageIcon icon = new ImageIcon("varsity image logo.jpg");
        Image img = icon.getImage().getScaledInstance(500, 400, Image.SCALE_SMOOTH);
        gifLabel = new JLabel(new ImageIcon(img));
//        gifLabel = new JLabel(new ImageIcon("hva-hogeschool-van-amsterdam.gif"));
        gifPanel.add(gifLabel, BorderLayout.WEST);
        gifPanel.setBackground(new Color(52, 161, 235));

        //information and contact details label
        JLabel infoLabel = new JLabel("<html>Welcome to the Central Application Office.<br>"
                + "We are dedicated to providing assistance<br>"
                + "to all applicants for various programs.<br>"
                + "Contact us:<br>"
                + "Email: info@centralappoffice.com<br>"
                + "Phone: 021 345 6789</html>");

        infoLabel.setFont(font2);
        gifPanel.add(infoLabel, BorderLayout.EAST);
        add(gifPanel, BorderLayout.CENTER);
        pack();
        setLocationRelativeTo(null);
        setVisible(true);

        Timer timer = new Timer(5000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Dispose the GIF page after 5 seconds and show the login GUI
                remove(gifPanel);
                dispose();
                setLoginGui();
            }
        });
        timer.setRepeats(false);
        timer.start();
    }
//**************************************End Welcome***************************************     

    public void setLoginGui() {
        this.add(panelSouth, BorderLayout.SOUTH);
        this.add(panelNorth, BorderLayout.NORTH);
        this.add(panelCenter, BorderLayout.CENTER);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setSize(900, 400);
        this.setVisible(true);
        this.setResizable(false);
        this.setLocationRelativeTo(null);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnLogin) {
            String email = txtEmail.getText();
            String password = new String(txtPassword.getPassword());
            System.out.println("Email entered: " + email); // Add this line to check the email value
            UserDAO userDAO = new UserDAO();
            boolean loginSuccessful = userDAO.login(email, password);

            if (loginSuccessful) {
                // Do something if login is successful
                JOptionPane.showMessageDialog(this, "Login successful!", "Success", JOptionPane.INFORMATION_MESSAGE);
                // If the username and password are valid, show the PersonalDetialsGUI window
                ApplicantDetailsGUI personalDetailsGUI = new ApplicantDetailsGUI(email);
                personalDetailsGUI.setP_D_GUI();
                dispose();
            } else {
                // Do something if login fails
                JOptionPane.showMessageDialog(this, "Invalid email or password.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else if (e.getSource() == btnRegister) {
            Register gui = new Register();
            gui.setRegisterGui();// open register Gorm
            this.dispose();
        } else if (e.getSource() == btnCForgotPassword) {
            // ForgotGui forgot new ForgotGui ();
            ForgotGui forgot = new ForgotGui();
            forgot.setGuiForgotPass();
            this.dispose();
        } else if (e.getSource() == btnExit) {
            System.exit(0);
        }
    }
}
