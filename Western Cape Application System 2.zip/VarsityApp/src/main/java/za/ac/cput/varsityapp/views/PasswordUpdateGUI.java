/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package za.ac.cput.varsityapp.views;

/**
 *
 * @author Skhoma
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import za.ac.cput.varsityapp.dao.UserDAO;

public class PasswordUpdateGUI extends JFrame implements ActionListener {

    private JTextField txtUsername;
    private JPasswordField txtNewPassword;
    private JButton btnUpdate, btnCancel;

    private UserDAO userDAO;
    private Font font1, font2, font3;

    public PasswordUpdateGUI() {

        setTitle("Password Update");
        userDAO = new UserDAO();
        font1 = new Font("Times New Roman", Font.BOLD, 28);
        font2 = new Font("Times New Roman", Font.ITALIC, 22);
        font3 = new Font("Arial", Font.BOLD, 15);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(3, 2));

        JLabel lblUsername = new JLabel("Username:");
        lblUsername.setFont(font3);
        JLabel lblNewPassword = new JLabel("New Password:");
        lblNewPassword.setFont(font3);

        txtUsername = new JTextField();
        txtUsername.setFont(font3);
        txtNewPassword = new JPasswordField();
        txtNewPassword.setFont(font3);

        btnUpdate = new JButton("Update");
        btnUpdate.setFont(font2);
        btnCancel = new JButton("Cancel");
        btnCancel.setFont(font2);
        btnUpdate.addActionListener(this);
        btnCancel.addActionListener(this);

        panel.add(lblUsername);
        panel.add(txtUsername);
        panel.add(lblNewPassword);
        panel.add(txtNewPassword);
        panel.add(btnUpdate);
        panel.add(btnCancel);

        add(panel);
    }

    public void setPasswordUpdateGUI() {
        setSize(300, 200);
        //  setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        this.setLocationRelativeTo(null);
        this.setVisible(true);
        this.setResizable(false);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnUpdate) {
            String username = txtUsername.getText();
            String newPassword = new String(txtNewPassword.getPassword());

            userDAO.updatePassword(username, newPassword);

            // Show a confirmation message
            JOptionPane.showMessageDialog(this, "Password updated successfully!");

            // Clear the input fields
            txtUsername.setText("");
            txtNewPassword.setText("");
        } else if (e.getSource() == btnCancel) {
            dispose();
        }
    }

    public static void main(String[] args) {
        new PasswordUpdateGUI().setPasswordUpdateGUI();
    }
}
