package za.ac.cput.varsityapp.views;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.table.*;
import za.ac.cput.varsityapp.dao.CourseSelectionDAO;
import za.ac.cput.varsityapp.domain.CourseSelectionPOJO;

/**
 *
 * @author Asimbonge Mbende(221090754)
 */
public class CourseSelectionGUI extends JFrame implements ActionListener {

    private DefaultTableModel tableModel;
    private JPanel pnNorth, pnCenter, pnSouth;
    private JLabel lblMainHeading, lblTable, lblChoice1, lblChoice2, lblChoice3;
    private JComboBox<String> cmbCourses;
    private JTable courseTable;
    private JButton btnBack, btnShowInstitutions, btnNext;
    private Font font1, font2, font3;
    private CourseSelectionDAO courseSelectionDAO;
    private String studentEmail;

    public CourseSelectionGUI(String email) {
        setTitle("Course Selection Page");
        //Changes the default java logo
        try {
            BufferedImage customIconImage = ImageIO.read(new File("Logo2.jpg"));
            // Set the custom icon for the JFrame
            setIconImage(customIconImage);
        } catch (IOException ex) {
            // Handle any errors while loading the image (optional)
            ex.printStackTrace();
        }
        pnNorth = new JPanel();
        pnCenter = new JPanel();
        pnSouth = new JPanel();
        this.getContentPane().setLayout(new BorderLayout());
        courseSelectionDAO = new CourseSelectionDAO();
        font1 = new Font("Times New Roman", Font.BOLD, 28);
        font2 = new Font("Times New Roman", Font.ITALIC, 22);
        font3 = new Font("Arial", Font.BOLD, 15);
        this.studentEmail = email;
        lblMainHeading = new JLabel("Choose courses(max 3)");
        lblMainHeading.setFont(font1);
        lblMainHeading.setForeground(new Color(10, 10, 10));
        lblMainHeading.setHorizontalAlignment(SwingConstants.CENTER);

        lblChoice1 = new JLabel("First Choice:");
        lblChoice1.setForeground(new Color(15, 194, 252));
        lblChoice1.setFont(font2);

        lblChoice2 = new JLabel("Second Choice:");
        lblChoice2.setForeground(new Color(15, 194, 252));
        lblChoice2.setFont(font2);

        lblChoice3 = new JLabel("Third Choice:");
        lblChoice3.setForeground(new Color(15, 194, 252));
        lblChoice3.setFont(font2);

        cmbCourses = new JComboBox(new String[]{"---Select Course---"});
        courseSelectionDAO.populateComboBox(cmbCourses);
        cmbCourses.setFont(font3);

        lblTable = new JLabel("You qualify to apply for:");
        lblTable.setFont(font1);
        lblTable.setForeground(new Color(10, 10, 10));
        lblTable.setHorizontalAlignment(SwingConstants.CENTER);
        tableModel = new DefaultTableModel();
        courseTable = new JTable(tableModel);
        tableModel.addColumn("Course Name");
        tableModel.addColumn("Institution");
        tableModel.addColumn("Fees");

        btnBack = new JButton("Back");
        btnBack.setBackground(Color.red);

        btnShowInstitutions = new JButton("Show Institutions");
        btnShowInstitutions.setBackground(Color.GRAY);

        btnNext = new JButton("Next");
        btnNext.setBackground(new Color(39, 214, 53));

        cmbCourses.addActionListener(this);
        btnBack.addActionListener(this);
        btnShowInstitutions.addActionListener(this);
        btnNext.addActionListener(this);
    }

    public void setC_S_GUI() {
        pnNorth.setLayout(new GridLayout(7, 1));
        pnCenter.setLayout(new GridLayout(3, 1));
        pnSouth.setLayout(new GridLayout(1, 2));

        pnNorth.add(lblMainHeading);
        pnNorth.add(cmbCourses);

        pnNorth.add(lblChoice1);

        pnNorth.add(lblChoice2);

        pnNorth.add(lblChoice3);

        pnCenter.add(lblTable);
        courseTable.setModel(tableModel);
        pnCenter.add(new JScrollPane(courseTable));

        pnSouth.add(btnBack);
        btnBack.setFont(font2);
        pnSouth.add(btnShowInstitutions);
        btnShowInstitutions.setFont(font2);
        pnSouth.add(btnNext);
        btnNext.setFont(font2);

        this.getContentPane().add(pnNorth, BorderLayout.NORTH);

        this.getContentPane().add(pnCenter, BorderLayout.CENTER);
        this.getContentPane().add(pnSouth, BorderLayout.SOUTH);

        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(900, 600);
        this.setLocationRelativeTo(null);
        this.setVisible(true);
    }

    private void updateLabels() {
        String selectedCourse = (String) cmbCourses.getSelectedItem();
        if (selectedCourse != null && !selectedCourse.equals("---Select Course---")) {
            if (lblChoice1.getText().equals("First Choice:")) {
                lblChoice1.setText("First Choice: " + selectedCourse);
                lblChoice1.setForeground(Color.red);
            } else if (lblChoice2.getText().equals("Second Choice:")) {
                lblChoice2.setText("Second Choice: " + selectedCourse);
                lblChoice2.setForeground(Color.red);
            } else if (lblChoice3.getText().equals("Third Choice:")) {
                lblChoice3.setText("Third Choice: " + selectedCourse);
                lblChoice3.setForeground(Color.red);
            }
        }
    }

    private int parseAdmissionRequirement(String requirement) {
        try {
            return Integer.parseInt(requirement);
        } catch (NumberFormatException e) {
            // Handle the case where the requirement is not a valid integer (e.g., display an error message)
            return Integer.MAX_VALUE; // Use a large value as a placeholder
        }
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == btnBack) {
            UploadResultsGUI urGUI = new UploadResultsGUI(studentEmail);
            urGUI.setResultsGUI();
            dispose();
        }
        if (ae.getSource() == cmbCourses) {
            updateLabels();
        }
        if (ae.getSource() == btnShowInstitutions) {
            String[] choices = {
                lblChoice1.getText().replace("First Choice: ", ""),
                lblChoice2.getText().replace("Second Choice: ", ""),
                lblChoice3.getText().replace("Third Choice: ", "")
            };
            
            int totalAPS = courseSelectionDAO.retrieveTotalAPS(studentEmail);
            String selectedCourse = (String) cmbCourses.getSelectedItem();

            if (selectedCourse != null) {
                tableModel.setRowCount(0); // Clear previous table data
                boolean anyCourseQualifies = false; // Flag to check if any course qualifies

                // Iterate over choices and universities
                for (String choice : choices) {
                    String[] universityNames = {"Cape Peninsula University of Technology", "University of Western Cape", "Stellenbosch University", "University of Cape Town"};

                    for (String universityName : universityNames) {
                        String[] data = courseSelectionDAO.retrieveAdmissionRequirementsAndFees(choice, universityName);
                        int admissionRequirement = parseAdmissionRequirement(data[0]);

                        if (totalAPS >= admissionRequirement) {
                            tableModel.addRow(new Object[]{choice, universityName, data[1]});
                            anyCourseQualifies = true;
                        }
                    }
                }

                if (!anyCourseQualifies) {
                    JOptionPane.showMessageDialog(this, "Based on your APS score, you unfortunately do not qualify for any of the selected courses.", "Course Selection", JOptionPane.WARNING_MESSAGE);
                    lblChoice1.setText("First Choice:");
                    lblChoice1.setForeground(new Color(15, 194, 252));
                    lblChoice2.setText("Second Choice:");
                    lblChoice2.setForeground(new Color(15, 194, 252));
                    lblChoice3.setText("Third Choice:");
                    lblChoice3.setForeground(new Color(15, 194, 252));
                    cmbCourses.setSelectedIndex(0);
                }
            } else {
                JOptionPane.showMessageDialog(this, "Invalid APS score. Please enter a valid APS score.", "Course Selection", JOptionPane.WARNING_MESSAGE);
            }
        }
        if (cmbCourses.getSelectedIndex() == 0) {
            cmbCourses.setSelectedIndex(-1);
        }
        if (ae.getSource() == btnNext) {
            // saveCoursesToFile();
            // Save the qualified courses to the database
            for (int i = 0; i < tableModel.getRowCount(); i++) {

                String institution = (String) tableModel.getValueAt(i, 0);
                String course = (String) tableModel.getValueAt(i, 1);
                String feeText = (String) tableModel.getValueAt(i, 2);
                String cleanFeeText = feeText.replaceAll("[^\\d.]", ""); // Remove non-numeric characters
                double fee = Double.parseDouble(cleanFeeText); // Parse the cleaned fee value

                CourseSelectionPOJO courseSelectionPOJO = new CourseSelectionPOJO(studentEmail,institution, course, fee);
                courseSelectionDAO.saveCourses(courseSelectionPOJO);
            }
            CourseFeeGUI courseFeeGUI = new CourseFeeGUI(studentEmail);
            courseFeeGUI.setCourseFeeGUI();
            dispose();
        }

    }

//    public static void main(String[] args) {
//        new CourseSelectionGUI().setC_S_GUI();
//    }

}
