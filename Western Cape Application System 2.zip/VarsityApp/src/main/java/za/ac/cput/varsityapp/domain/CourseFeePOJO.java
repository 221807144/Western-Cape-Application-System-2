/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.cput.varsityapp.domain;

/**
 *
 * @author user
 */
public class CourseFeePOJO {
     private String courseName;
    private String institution;
    private double fee;
    private String bursary;

    public CourseFeePOJO(String courseName, String institution, double fee) {
        this.courseName = courseName;
        this.institution = institution;
        this.fee = fee;
    }

    public CourseFeePOJO(String courseName, String bursary) {
        this.courseName = courseName;
        this.bursary = bursary;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public String getInstitution() {
        return institution;
    }

    public void setInstitution(String institution) {
        this.institution = institution;
    }

    public double getFee() {
        return fee;
    }

    public void setFee(double fee) {
        this.fee = fee;
    }

    public String getBursary() {
        return bursary;
    }

    public void setBursary(String bursary) {
        this.bursary = bursary;
    }
    
}
