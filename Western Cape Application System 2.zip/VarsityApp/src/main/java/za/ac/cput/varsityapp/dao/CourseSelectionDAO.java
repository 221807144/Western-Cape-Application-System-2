package za.ac.cput.varsityapp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import za.ac.cput.varsityapp.connection.DBConnection;
import za.ac.cput.varsityapp.domain.CourseSelectionPOJO;

/**
 *
 * @author user
 */
public class CourseSelectionDAO {

    private Connection conn;
    private PreparedStatement prepStmt;
    private Statement stmt;
    private ResultSet resultSet;

    public CourseSelectionDAO() {
        try {
            this.conn = DBConnection.derbyConnection();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error: Failed to establish database connection" + ex.getMessage());
        }
    }

    public void populateComboBox(JComboBox cbCourseList) {
        String sql = "SELECT * FROM Courses";
        resultSet = null;

        try {
            stmt = this.conn.createStatement();
            resultSet = stmt.executeQuery(sql);

            while (resultSet.next()) {
                cbCourseList.addItem(resultSet.getString("Course_Name"));
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error: " + ex);
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, ex.getMessage(), "Warning", JOptionPane.ERROR_MESSAGE);
            }
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, ex.getMessage(), "Warning", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public void saveCourses(CourseSelectionPOJO c_s_pojo) {
        String insertQuery = "INSERT INTO Enrolmennts (Email,Institution,Course_Name,Fees) VALUES (?, ?, ?, ?)";
        try {                              
            prepStmt = this.conn.prepareStatement(insertQuery);
            prepStmt.setString(1, c_s_pojo.getEmail());
            prepStmt.setString(2, c_s_pojo.getInstitution());
            prepStmt.setString(3, c_s_pojo.getCourseName());
            prepStmt.setDouble(4, c_s_pojo.getFee());
            prepStmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (prepStmt != null) {
                    prepStmt.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    public int retrieveTotalAPS(String email) {
    int totalAPS = 0;
    String query = "SELECT Total_App_Score FROM TotalAPS WHERE Email=?";
    PreparedStatement prepStmt = null;
    ResultSet resultSet = null;
    
    try {
        prepStmt = this.conn.prepareStatement(query);
        prepStmt.setString(1, email); // Set the email parameter
        resultSet = prepStmt.executeQuery();
        
        if (resultSet.next()) {
            totalAPS = resultSet.getInt("Total_App_Score");
            // Line for debugging
            System.out.println("Total APS from database: " + totalAPS);
        }
    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        try {
            if (resultSet != null) {
                resultSet.close();
            }
            if (prepStmt != null) {
                prepStmt.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    return totalAPS;
}


//    public int retrieveTotalAPS() {
//        int totalAPS = 0;
//        String query = "SELECT Total_App_Score FROM TotalAPS WHERE Email=?";
//        prepStmt = null;
//        resultSet = null;
//        try {
//            prepStmt = this.conn.prepareStatement(query);
//            resultSet = prepStmt.executeQuery();
//            if (resultSet.next()) {
//                totalAPS = resultSet.getInt("Total_App_Score");
//                // Line for debugging
//                System.out.println("Total APS from database: " + totalAPS);
//            }
//        } catch (SQLException e) {
//            e.printStackTrace();
//        } finally {
//            try {
//                if (resultSet != null) {
//                    resultSet.close();
//                }
//                if (prepStmt != null) {
//                    prepStmt.close();
//                }
//            } catch (SQLException e) {
//                e.printStackTrace();
//            }
//        }
//        return totalAPS;
//    }

    public String[] retrieveAdmissionRequirementsAndFees(String course, String university) {
        resultSet = null;
        String[] admissionAndFees = new String[2];

        try {
            String sqlQuery = "SELECT Min_Requirements, Fees "
                    + "FROM ADMISSIONREQUIREMENTS "
                    + "WHERE University = ? AND Course = ?";
            prepStmt = this.conn.prepareStatement(sqlQuery);
            prepStmt.setString(1, university);
            prepStmt.setString(2, course);
            resultSet = prepStmt.executeQuery();

            if (resultSet.next()) {
                admissionAndFees[0] = resultSet.getString("Min_Requirements");
                admissionAndFees[1] = resultSet.getString("Fees");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (prepStmt != null) {
                    prepStmt.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return admissionAndFees;
    }
}
