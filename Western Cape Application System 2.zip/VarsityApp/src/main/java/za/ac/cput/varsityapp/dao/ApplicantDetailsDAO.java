/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.cput.varsityapp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import za.ac.cput.varsityapp.connection.DBConnection;
import za.ac.cput.varsityapp.domain.ApplicantDetailsPOJO;

/**
 *
 * @author applicant
 */
public class ApplicantDetailsDAO {

    private Connection conn;
    private PreparedStatement preStmnt;
    private Statement stmt;

    public ApplicantDetailsDAO() {
        try {
            this.conn = DBConnection.derbyConnection();
        } catch (SQLException ex) {
         System.out.println( "Error: Failed to establish database connection" + ex.getMessage());
        }
    }

    public ApplicantDetailsPOJO save(ApplicantDetailsPOJO applicant) {
        int ok;

        try {
            stmt = this.conn.createStatement();
            ok = stmt.executeUpdate("INSERT INTO PersonalDetails VALUES('" + applicant.getTitle() + "','"
                    + applicant.getFirstName() + "','"
                    + applicant.getLastName() + "','"
                    + applicant.getGender() + "','"
                    + applicant.getEmail() + "','"
                    + applicant.getCellNo() + "','"
                    + applicant.getAddress() + "')");
            if (ok > 0) {
             System.out.println("Success: Applicant's Information saved");
//                JOptionPane.showMessageDialog(null, "Success: Applicant's Information saved");

            } else {
              System.out.println("Error : Applicant's Information could not be saved");
//                JOptionPane.showMessageDialog(null, "Error : Applicant's Information could not be saved");
            }
        } catch (SQLException sqlException) {
           sqlException.printStackTrace();

        } catch (Exception e) {
           e.printStackTrace();

        } finally {
            // Close the Statement and PreparedStatement in a finally block
            try {
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException ex) {
                // Handle the exception or log it as needed
                ex.printStackTrace();
            }
        }
        return applicant;
    }

    public boolean deleteStudent(String student) {

        try {
            String sql = "DELETE FROM PersonalDetails WHERE Email = ?";
            preStmnt = this.conn.prepareStatement(sql);
            preStmnt.setString(1, student);
            int rowsAffected = preStmnt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException ex) {
           ex.printStackTrace();
            return false;
        } finally {
            // Close the Statement and PreparedStatement in a finally block
            try {
                if (preStmnt != null) {
                    preStmnt.close();
                }
            } catch (SQLException ex) {
                // Handle the exception or log it as needed
                ex.printStackTrace();
            }
        }

    }
public ApplicantDetailsPOJO getStudEmail(String email) {
    String sql = "SELECT Title, FirstName, LastName, Gender, CellNumber, Address FROM PersonalDetails WHERE Email = ?";
    try {
        preStmnt = this.conn.prepareStatement(sql);
        preStmnt.setString(1, email);
        ResultSet rs = preStmnt.executeQuery();
        if (rs.next()) {
            String title = rs.getString("Title");
            String firstName = rs.getString("FirstName");
            String lastName = rs.getString("LastName");
            String gender = rs.getString("Gender");
            String cellNo = rs.getString("CellNumber");
            String address = rs.getString("Address");
            return new ApplicantDetailsPOJO(title, firstName, lastName, gender, email, cellNo, address);
        }
    } catch (SQLException ex) {
        ex.printStackTrace();
    } finally {
        try {
            if (preStmnt != null) {
                preStmnt.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    return null;
}

public String getEmail(String email) {
    String query = "SELECT Email FROM PersonalDetails WHERE Email = ?";
    try {
        preStmnt = conn.prepareStatement(query);
        preStmnt.setString(1, email);
        ResultSet rs = preStmnt.executeQuery();
        if (rs.next()) {
            return rs.getString("Email");
        }
    } catch (SQLException ex) {
        ex.printStackTrace();
    } finally {
        try {
            if (preStmnt != null) {
                preStmnt.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    return null;
}
//      OLD
//    public ApplicantDetailsPOJO getStudEmail(String email) {
//
//        try {
//            String sql = "SELECT Email FROM PersonalDetails WHERE Email = ?";
//            preStmnt = this.conn.prepareStatement(sql);
//            preStmnt.setString(1, email);
//            ResultSet rs = preStmnt.executeQuery();
//
//            if (rs.next()) {
//                String title = rs.getString("Title");
//                String firstName = rs.getString("FirstName");
//                String lastName = rs.getString("LastName");
//                String gender = rs.getString("Gender");
//                String CellNo = rs.getString("CellNumber");
//                String address = rs.getString("Address");
//                return new ApplicantDetailsPOJO(title, firstName, lastName, gender, email, CellNo, address);
//            }
//        } catch (SQLException ex) {
//           ex.printStackTrace();
//        } finally {
//            // Close the Statement and PreparedStatement in a finally block
//            try {
//                if (preStmnt != null) {
//                    preStmnt.close();
//                }
//            } catch (SQLException ex) {
//                // Handle the exception or log it as needed
//                ex.printStackTrace();
//            }
//        }
//
//        return null;
//    }
//      OLD
//    public ArrayList<String> getEmails() {
//        ArrayList<String> emailList = new ArrayList<>();
//        String query = "SELECT Email FROM PersonalDetails WHERE Email = ?";
//
//        ResultSet rs = null;
//        try {
//            stmt = this.conn.createStatement();
//            rs = stmt.executeQuery(query);
//            while (rs.next()) {
//                String email = rs.getString("Email");
//                emailList.add(email);
//            }
//        } catch (SQLException ex) {
//           ex.printStackTrace();
//        } finally {
//            // Close the Statement and PreparedStatement in a finally block
//            try {
//                if (stmt != null) {
//                    stmt.close();
//                }
//
//            } catch (SQLException ex) {
//                // Handle the exception or log it as needed
//                ex.printStackTrace();
//            }
//        }
//        return emailList;
//    }

    public boolean updateStudent(ApplicantDetailsPOJO student) {
        String query = "UPDATE PersonalDetails SET Title = ?, FirstName = ?, LastName = ?,Gender = ?,CellNumber = ?,Address = ? WHERE Email = ?";
        try {
            preStmnt = this.conn.prepareStatement(query);
            preStmnt.setString(1, student.getTitle());
            preStmnt.setString(2, student.getFirstName());
            preStmnt.setString(3, student.getLastName());
            preStmnt.setString(4, student.getGender());
            preStmnt.setString(5, student.getCellNo());
            preStmnt.setString(6, student.getAddress());
            preStmnt.setString(7, student.getEmail());
            int rowsAffected = preStmnt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException ex) {
            ex.printStackTrace();  // Print the full stack trace
//            JOptionPane.showMessageDialog(null, ex.getMessage(), "Warning", JOptionPane.ERROR_MESSAGE);
            return false;
        } finally {
            // Close the Statement and PreparedStatement in a finally block
            try {

                if (preStmnt != null) {
                    preStmnt.close();
                }
            } catch (SQLException ex) {
                // Handle the exception or log it as needed
                ex.printStackTrace();
            }
        }
    }
}
