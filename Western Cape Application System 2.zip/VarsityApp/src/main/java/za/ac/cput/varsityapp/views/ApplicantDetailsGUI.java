/*
 * To change pnCenter license header, choose License Headers in Project Properties.
 * To change pnCenter template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.cput.varsityapp.views;

import java.awt.*;
import za.ac.cput.varsityapp.domain.ApplicantDetailsPOJO;
import za.ac.cput.varsityapp.dao.ApplicantDetailsDAO;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import javax.imageio.ImageIO;
import javax.swing.*;
//import org.apache.commons.validator.EmailValidator;
import org.apache.commons.validator.routines.EmailValidator;

/**
 *
 * @author Asimbonge Mbende(221090754)
 */
public class ApplicantDetailsGUI extends JFrame implements ActionListener, ItemListener {

    private JPanel pnNorth, pnCenter, pnSouth;

    private ArrayList<String> emailList;
    private JLabel lblDelete;
    private JComboBox<String> cmbEmailList;

    private JLabel lblUpdate;
    private ArrayList<String> emailList2;
    private JComboBox<String> cmbEmailList2;

    private JLabel lblTitle;
    private JComboBox<String> cboTitle;
    private JLabel lblErrorTitle;

    private JLabel lblFirstName;
    private JTextField txtFirstName;
    private JLabel lblErrorFirstName;

    private JLabel lblLastName;
    private JTextField txtLastName;
    private JLabel lblErrorLastName;

    private JLabel lblGender;
    private JPanel panelGender;
    private JRadioButton radFemale;
    private JRadioButton radMale;
    private JLabel lblErrorGender;
    private ButtonGroup genderButtonGroup;

    private JLabel lblEmail;
    private JTextField txtEmail;
    private JLabel lblErrorEmail;

    private JLabel lblCellNo;
    private JTextField txtCellNo;
    private JLabel lblErrorCellNo;

    private JLabel lblAddress;
    private JTextField txtAddress;
    private JLabel lblErrorAddress;

    private JLabel lblTerms;
    private JCheckBox chkTerms;
    private JLabel lblErrorTerms;

    private JButton btnNext;
    private JButton btnClear;
    private JButton btnBack;
    private JButton btnDelete;
    private JButton btnUpdate;
    private Font font1, font2, font3, font4;
    ApplicantDetailsDAO applicantDAO;
    ApplicantDetailsPOJO applicant;
    private String studentEmail;

    //pnCenter constructor is where we will initiate our instance  valiables
    public ApplicantDetailsGUI(String email) {
        super("Applicant Personal Details");
        //Changes the default java logo
        try {
            BufferedImage customIconImage = ImageIO.read(new File("Logo2.jpg"));
            // Set the custom icon for the JFrame
            setIconImage(customIconImage);
        } catch (IOException ex) {
            // Handle any errors while loading the image (optional)
            ex.printStackTrace();
        }
        font1 = new Font("Times New Roman", Font.BOLD, 28);
        font2 = new Font("Times New Roman", Font.ITALIC, 22);
        font4 = new Font("Times New Roman", Font.ITALIC, 19);
        font3 = new Font("Arial", Font.BOLD, 15);
        this.studentEmail = email;
        pnNorth = new JPanel();
        pnCenter = new JPanel();
        pnSouth = new JPanel();
        applicantDAO = new ApplicantDetailsDAO();
        applicant = new ApplicantDetailsPOJO();

        lblDelete = new JLabel("Select Email to Delete: ");
        lblDelete.setFont(font3);
        emailList = new ArrayList<>(Arrays.asList(email));
        cmbEmailList = new JComboBox<>(emailList.toArray(new String[0]));
        cmbEmailList.setFont(font3);

        lblUpdate = new JLabel("Select Email to Update: ");
        lblUpdate.setFont(font3);
        emailList2 = new ArrayList<>(Arrays.asList(email));
        cmbEmailList2 = new JComboBox<>(emailList2.toArray(new String[0]));
        cmbEmailList2.setFont(font3);

        lblTitle = new JLabel("Title: ");
        lblTitle.setFont(font1);
        String listOfTitles[] = {"Dr", "Adv", "Judge", "Rev", "Prof", "Mr", "Mrs", "Miss"};
        cboTitle = new JComboBox(listOfTitles);
        cboTitle.setFont(font2);
        lblErrorTitle = new JLabel("*required.Please provide title");
        lblErrorTitle.setFont(font3);
        lblErrorTitle.setForeground(Color.red);
        lblErrorTitle.setVisible(false);

        lblFirstName = new JLabel("First Name: ");
        lblFirstName.setFont(font1);
        txtFirstName = new JTextField(20);
        setPlaceholder(txtFirstName, "e.g John", Color.GRAY);
        txtFirstName.setFont(font2);
        lblErrorFirstName = new JLabel("*required.Please provide First Name");
        lblErrorFirstName.setFont(font3);
        lblErrorFirstName.setForeground(Color.red);
        lblErrorFirstName.setVisible(false);

        lblLastName = new JLabel("Last Name: ");
        lblLastName.setFont(font1);
        txtLastName = new JTextField(20);
        setPlaceholder(txtLastName, "e.g Smith", Color.GRAY);
        txtLastName.setFont(font2);
        lblErrorLastName = new JLabel("*required.Please provide Last Name");
        lblErrorLastName.setFont(font3);
        lblErrorLastName.setForeground(Color.red);
        lblErrorLastName.setVisible(false);

        lblGender = new JLabel("Gender: ");
        lblGender.setFont(font1);

        panelGender = new JPanel();
        radFemale = new JRadioButton("Female");
        radFemale.setFont(font2);
        radMale = new JRadioButton("Male");
        radMale.setFont(font2);
        genderButtonGroup = new ButtonGroup();
        genderButtonGroup.add(radFemale);
        genderButtonGroup.add(radMale);
        panelGender.setLayout(new GridLayout(1, 2));
        radFemale.setSelected(true);//make the female option default
        panelGender.add(radFemale);
        panelGender.add(radMale);
        lblErrorGender = new JLabel("*required.Please provide Gender");
        lblErrorGender.setFont(font3);
        lblErrorGender.setForeground(Color.red);
        lblErrorGender.setVisible(false);

        lblEmail = new JLabel("Email: ");
        lblEmail.setFont(font1);
        txtEmail = new JTextField(20);
        setPlaceholder(txtEmail, "e.g johnsmith@gmail.com", Color.GRAY);
        txtEmail.setFont(font2);
        lblErrorEmail = new JLabel("*required.Please provide valid Email");
        lblErrorEmail.setFont(font3);
        lblErrorEmail.setForeground(Color.red);
        lblErrorEmail.setVisible(false);

        lblCellNo = new JLabel("Cell Number: ");
        lblCellNo.setFont(font1);
        txtCellNo = new JTextField();
        setPlaceholder(txtCellNo, "e.g 0123456789", Color.GRAY);
        txtCellNo.setFont(font2);
        lblErrorCellNo = new JLabel("*input must contain exactly 10 numbers");
        lblErrorCellNo.setFont(font3);
        lblErrorCellNo.setForeground(Color.red);
        lblErrorCellNo.setVisible(false);

        lblAddress = new JLabel("Address: ");
        lblAddress.setFont(font1);
        txtAddress = new JTextField();
        setPlaceholder(txtAddress, "e.g District 6,Cape Town,8001", Color.GRAY);
        txtAddress.setFont(font2);
        lblErrorAddress = new JLabel("*required.Please provide address");
        lblErrorAddress.setFont(font3);
        lblErrorAddress.setForeground(Color.red);
        lblErrorAddress.setVisible(false);

        lblTerms = new JLabel("Terms and Conditions: ");
        lblTerms.setFont(font1);
        chkTerms = new JCheckBox("I agree to the terms and conditions");
        chkTerms.setFont(font4);
        lblErrorTerms = new JLabel("*required.Please accept the Ts & Cs");
        lblErrorTerms.setFont(font3);
        lblErrorTerms.setForeground(Color.red);
        lblErrorTerms.setVisible(false);

        btnNext = new JButton("Next");
        btnClear = new JButton("Clear");
        btnBack = new JButton("Back");
        btnDelete = new JButton("Delete");
        btnUpdate = new JButton("Update");
        btnNext.setEnabled(false);

    }
    // Method to set placeholder text and color for a JTextField

    private void setPlaceholder(JTextField textField, String placeholder, Color placeholderColor) {
        textField.setText(placeholder);
        textField.setForeground(placeholderColor);

        textField.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {
                if (textField.getText().equals(placeholder)) {
                    textField.setText("");
                    textField.setForeground(Color.BLACK);
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if (textField.getText().isEmpty()) {
                    textField.setText(placeholder);
                    textField.setForeground(placeholderColor);
                }
            }
        });
    }

    void setP_D_GUI() {
        //pnCenter place all gui components on the frame....gridLayout(9 Rows and 3 Columns )
        pnNorth.setLayout(new FlowLayout());
        pnCenter.setLayout(new GridLayout(8, 3));
        pnSouth.setLayout(new GridLayout(1, 5));

        pnNorth.add(lblDelete);
        pnNorth.add(cmbEmailList);

        pnNorth.add(lblUpdate);
        pnNorth.add(cmbEmailList2);

        pnCenter.add(lblTitle);
        pnCenter.add(cboTitle);
        pnCenter.add(lblErrorTitle);

        pnCenter.add(lblFirstName);
        pnCenter.add(txtFirstName);
        pnCenter.add(lblErrorFirstName);

        pnCenter.add(lblLastName);
        pnCenter.add(txtLastName);
        pnCenter.add(lblErrorLastName);

        pnCenter.add(lblGender);
        pnCenter.add(panelGender);
        pnCenter.add(lblErrorGender);

        pnCenter.add(lblEmail);
        pnCenter.add(txtEmail);
        pnCenter.add(lblErrorEmail);

        pnCenter.add(lblCellNo);
        pnCenter.add(txtCellNo);
        pnCenter.add(lblErrorCellNo);

        pnCenter.add(lblAddress);
        pnCenter.add(txtAddress);
        pnCenter.add(lblErrorAddress);

        pnCenter.add(lblTerms);
        pnCenter.add(chkTerms);
        pnCenter.add(lblErrorTerms);

        pnSouth.add(btnBack);
        btnBack.setFont(font2);
        btnBack.setBackground(Color.red);

        pnSouth.add(btnClear);
        btnClear.setFont(font2);
        btnClear.setBackground(Color.GRAY);
        btnClear.setEnabled(false);

        pnSouth.add(btnUpdate);
        btnUpdate.setFont(font2);
        btnUpdate.setBackground(new Color(19, 118, 201));
        btnUpdate.setEnabled(false);

        pnSouth.add(btnDelete);
        btnDelete.setFont(font2);
        btnDelete.setEnabled(false);

        pnSouth.add(btnNext);
        btnNext.setFont(font2);
        btnNext.setBackground(new Color(39, 214, 53));

        btnNext.addActionListener(this);
        btnClear.addActionListener(this);
        btnBack.addActionListener(this);
        btnDelete.addActionListener(this);
        btnUpdate.addActionListener(this);
        chkTerms.addActionListener(this);
        cmbEmailList.addItemListener(this);
        cmbEmailList2.addItemListener(this);

        add(pnNorth, BorderLayout.NORTH);
        add(pnCenter, BorderLayout.CENTER);
        add(pnSouth, BorderLayout.SOUTH);
        //To make the GUI Visible and set it
        populateComboBox();
        populateComboBox2();
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setSize(900, 600);
        this.setLocationRelativeTo(null);
        this.setVisible(true);

    }

    private void populateComboBox() {
        cmbEmailList.removeAllItems();
        cmbEmailList.addItem("---no selection made---");

        String email = applicantDAO.getEmail(studentEmail);
        if (email != null) {
            cmbEmailList.addItem(email);
        }
        cmbEmailList.setSelectedIndex(0);
    }

    private void populateComboBox2() {
        cmbEmailList2.removeAllItems();
        cmbEmailList2.addItem("---no selection made---");

        String email = applicantDAO.getEmail(studentEmail);
        if (email != null) {
            cmbEmailList2.addItem(email);
        }
        cmbEmailList2.setSelectedIndex(0);
    }

    public boolean isInputValid() {
        boolean valid = true;
        if (cboTitle.getSelectedIndex() == -1) {
            valid = false;
            lblErrorTitle.setVisible(true);
        } else {
            lblErrorTitle.setVisible(false);
        }

        // Validate first name
        String firstName = txtFirstName.getText();
        if (txtFirstName.getText().equals("")) {
            valid = false;
            lblErrorFirstName.setVisible(true);
        } else if (firstName.length() < 2 || !firstName.matches("^[a-zA-Z ]+$")) {
            valid = false;
            lblErrorFirstName.setText("Please provide valid first name");
            lblErrorFirstName.setVisible(true);
        } else {
            lblErrorFirstName.setVisible(false);
        }

        // Validate last name
        String lastName = txtLastName.getText();
        if (txtLastName.getText().equals("")) {
            valid = false;
            lblErrorLastName.setVisible(true);
        } else if (lastName.length() < 2 || !lastName.matches("^[a-zA-Z ]+$")) {
            valid = false;
            lblErrorLastName.setText("Please provide valid last name");
            lblErrorLastName.setVisible(true);
        } else {
            lblErrorLastName.setVisible(false);
        }

        if (!radFemale.isSelected() && !radMale.isSelected()) {
            valid = false;
            lblErrorGender.setText("Please select a gender");
            lblErrorGender.setVisible(true);
        } else {
            lblErrorGender.setVisible(false);
        }

        if (!EmailValidator.getInstance().isValid(txtEmail.getText())) {
            valid = false;
            lblErrorEmail.setVisible(true);
        } else {
            lblErrorEmail.setVisible(false);
        }

        String input = txtCellNo.getText();
        if (input.length() != 10) {
            valid = false;

            lblErrorCellNo.setVisible(true);
            // \\d+ is a regular expression matches one or more digits
        } else if (!input.matches("\\d+")) {
            lblErrorCellNo.setText("*Input must only contain digits");
            lblErrorCellNo.setVisible(true);
        } else {
            lblErrorCellNo.setVisible(false);
        }

        // Validate address
        String address = txtAddress.getText();
        if (address.length() < 5 || !address.matches("[a-zA-Z0-9#,-/ ]+")) {
            valid = false;
            lblErrorAddress.setText("*required.Please provide valid address");
            lblErrorAddress.setVisible(true);
        } else {
            lblErrorAddress.setVisible(false);
        }

        return valid;
    }

    void resetForm() {
        cboTitle.setSelectedIndex(-1);
        txtFirstName.setText("");
        txtLastName.setText("");
        radFemale.setSelected(true);
        txtEmail.setText("");
        txtCellNo.setText("");
        txtAddress.setText("");
        chkTerms.setSelected(false);
        cmbEmailList.setSelectedIndex(0);
        cmbEmailList2.setSelectedIndex(0);
        btnNext.setEnabled(false);
        btnClear.setEnabled(false);

        //reset error labels
        lblErrorFirstName.setVisible(false);
        lblErrorLastName.setVisible(false);
        lblErrorEmail.setVisible(false);

        lblErrorCellNo.setVisible(false);
        lblErrorAddress.setVisible(false);
        setPlaceholder(txtFirstName, "e.g John", Color.GRAY);
        setPlaceholder(txtLastName, "e.g Smith", Color.GRAY);
        setPlaceholder(txtEmail, "e.g johnsmith@gmail.com", Color.GRAY);
        setPlaceholder(txtCellNo, "e.g 0123456789", Color.GRAY);
        setPlaceholder(txtAddress, "e.g District 6,Cape Town,8001", Color.GRAY);

    }

    private void handleTermsCheckBox() {
        if (chkTerms.isSelected()) {
            String title = cboTitle.getSelectedItem() != null ? cboTitle.getSelectedItem().toString() : "";
            String name = txtFirstName.getText();
            String surname = txtLastName.getText();
            String gender = radFemale.isSelected() ? "Female" : "Male";
            String email = txtEmail.getText();
            String cellNumber = txtCellNo.getText();
            String address = txtAddress.getText();

            if (title.isEmpty() || name.isEmpty() || surname.isEmpty() || gender.isEmpty() || email.isEmpty() || cellNumber.isEmpty() || address.isEmpty()) {
                lblErrorTerms.setText("Please fill in all the required fields.");
                lblErrorTerms.setVisible(true);
                btnNext.setEnabled(false);
                btnClear.setEnabled(false);
            } else {
                lblErrorTerms.setVisible(false);
                btnNext.setEnabled(true);
                btnClear.setEnabled(true);
            }
        } else {
            lblErrorTerms.setVisible(true);
            btnNext.setEnabled(false);
            btnClear.setEnabled(false);
        }
    }

    @Override

    public void actionPerformed(ActionEvent e) {
        String title = cboTitle.getSelectedItem() != null ? cboTitle.getSelectedItem().toString() : "";
        String name = txtFirstName.getText();
        String surname = txtLastName.getText();
        String gender = radFemale.isSelected() ? "Female" : "Male";
        String email = txtEmail.getText();
        String cellNumber = txtCellNo.getText();
        String address = txtAddress.getText();
        if (e.getSource() == btnNext) {
            if (isInputValid()) {
                ApplicantDetailsPOJO applicant = new ApplicantDetailsPOJO(title, name, surname, gender, email, cellNumber, address);
                applicantDAO.save(applicant);
                resetForm();
                JOptionPane.showMessageDialog(pnCenter, "Success: Applicant's Information saved");

                //JOptionPane.showMessageDialog(pnCenter, "Information saved successfully.Click OK to continue to the next page.");
                N_O_K_GUI nok = new N_O_K_GUI(email);
                nok.setN_O_K_GUI();
                dispose();

            } else {
                JOptionPane.showMessageDialog(pnCenter, "Please correct errors before saving.");

            }
        }

        if (e.getSource() == btnClear) {
            resetForm();
        }
        if (e.getSource() == btnDelete) {
            String selectedEmail = (String) cmbEmailList.getSelectedItem();
            int confirm = JOptionPane.showConfirmDialog(null, "Do you really want to delete the selected record?");

            if (confirm == JOptionPane.YES_OPTION) {
                boolean delete = applicantDAO.deleteStudent(selectedEmail);

                if (delete) {
                    JOptionPane.showMessageDialog(null, "You have successfully deleted the record of the applicant, with applicant Email: " + selectedEmail);
                    populateComboBox();
                    resetForm();
                    btnDelete.setEnabled(false);
                } else {
                    JOptionPane.showMessageDialog(null, "Failed to delete the record of the applicant.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
        if (e.getSource() == btnUpdate) {
            if (isInputValid()) {
                ApplicantDetailsPOJO updatedApplicant = new ApplicantDetailsPOJO(
                        cboTitle.getSelectedItem().toString(),
                        txtFirstName.getText(),
                        txtLastName.getText(),
                        radFemale.isSelected() ? "Female" : "Male",
                        txtEmail.getText(),
                        txtCellNo.getText(),
                        txtAddress.getText()
                );
                int confirm = JOptionPane.showConfirmDialog(null, "Do you really want to update the selected record?");
                if (confirm == JOptionPane.YES_OPTION) {
                    // Here, you should update the applicant information using the DAO's update method
                    boolean updateSuccessful = applicantDAO.updateStudent(updatedApplicant);

                    if (updateSuccessful) {
                        JOptionPane.showMessageDialog(
                                pnCenter,
                                "Information updated successfully."
                        );

                        // Optionally, you might want to repopulate the combo boxes
                        populateComboBox();
                        populateComboBox2();
//                    resetForm();
                    } else {
                        JOptionPane.showMessageDialog(
                                pnCenter,
                                "Failed to update applicant information.",
                                "Error",
                                JOptionPane.ERROR_MESSAGE
                        );
                    }
                }
            } else {
                JOptionPane.showMessageDialog(pnCenter, "Please correct errors before updating.");
            }
        } else if (e.getSource() == btnBack) {
            Login log = new Login();
            log.setLoginGui();
            dispose();

        }

        if (e.getSource() == chkTerms) {
            handleTermsCheckBox();
        }
    }

    @Override
    public void itemStateChanged(ItemEvent e) {
        if (e.getStateChange() == ItemEvent.SELECTED) {
            if (!cmbEmailList.getSelectedItem().equals("---no selection made---")) {
                String selectedEmail = (String) cmbEmailList.getSelectedItem();
                applicant = applicantDAO.getStudEmail(selectedEmail);

                if (applicant != null) {
                    cboTitle.setSelectedItem(applicant.getTitle());
                    txtFirstName.setText(applicant.getFirstName());
                    txtLastName.setText(applicant.getLastName());
                    if (applicant.getGender().equals("Female")) {
                        radFemale.setSelected(true);
                    } else {
                        radMale.setSelected(true);
                    }
                    txtEmail.setText(applicant.getEmail());
                    txtCellNo.setText(applicant.getCellNo());
                    txtAddress.setText(applicant.getAddress());
                    btnDelete.setEnabled(true);
                    btnClear.setEnabled(true);
                } else {
                    resetForm();
                    btnDelete.setEnabled(false);
                }
            }
        }

        if (e.getSource() == cmbEmailList2 && e.getStateChange() == ItemEvent.SELECTED) {
            String selectedStudNum = cmbEmailList2.getSelectedItem().toString();
            if (!selectedStudNum.equals("---no selection made---")) {
                applicant = applicantDAO.getStudEmail(selectedStudNum);
                if (applicant != null) {
                    cboTitle.setSelectedItem(applicant.getTitle());
                    txtFirstName.setText(applicant.getFirstName());
                    txtLastName.setText(applicant.getLastName());
                    if (applicant.getGender().equals("Female")) {
                        radFemale.setSelected(true);
                    } else {
                        radMale.setSelected(true);
                    }
                    txtEmail.setText(applicant.getEmail());
                    txtCellNo.setText(applicant.getCellNo());
                    txtAddress.setText(applicant.getAddress());
                    btnUpdate.setEnabled(true);
                    btnClear.setEnabled(true);
                }
            } else {
                resetForm();
                btnUpdate.setEnabled(false);
                btnClear.setEnabled(false);
            }
        }
    }

}
