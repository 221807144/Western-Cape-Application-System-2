/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.cput.varsityapp.domain;

/**
 *
 * @author user
 */
public class SubmissionPagePOJO {

    private String studentEmail;
    private String courseName;
    private String institution;
    private String studNum;


    public SubmissionPagePOJO() {
    }

    public SubmissionPagePOJO(String courseName, String institution, String studNum) {
        this.courseName = courseName;
        this.institution = institution;
        this.studNum = studNum;
    }

    public SubmissionPagePOJO(String studentEmail, String courseName, String institution, String studNum) {
        this.studentEmail = studentEmail;
        this.courseName = courseName;
        this.institution = institution;
        this.studNum = studNum;
    }
    
    public String getStudentEmail() {
        return studentEmail;
    }

//    }
    public void setStudentEmail(String studentEmail) {    
        this.studentEmail = studentEmail;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public String getInstitution() {
        return institution;
    }

    public void setInstitution(String institution) {
        this.institution = institution;
    }

    public String getStudNum() {
        return studNum;
    }

    public void setStudNum(String studNum) {
        this.studNum = studNum;
    }

 @Override
public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("Course Name: ").append(courseName).append("\n");
    sb.append("Institution: ").append(institution).append("\n");
    sb.append("Student Number: ").append(studNum).append("\n");
    return sb.toString();
}


}
