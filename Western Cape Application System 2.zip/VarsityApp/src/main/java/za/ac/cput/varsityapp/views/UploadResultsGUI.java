package za.ac.cput.varsityapp.views;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.imageio.ImageIO;
import javax.swing.*;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;
import za.ac.cput.varsityapp.dao.ResultsDAO;
import za.ac.cput.varsityapp.domain.UploadResultsPOJO;

/**
 *
 * @author Asimbonge Mbende(221090754)
 */
public class UploadResultsGUI extends JFrame implements ActionListener, ItemListener {

    private JPanel pnNorth, pnCenter, pnSouth;
    private JLabel lblHeading, lblHeading2, lblSubjects, lblResults, lblTotalScore, lblDelete, lblUpdate;
    private JTextField txtTotalScore;
    private JButton btnBack, btnShowAPS, btnNext, btnDelete, btnUpdate;
    private ArrayList<JComboBox<String>> cboSubjectsList = new ArrayList<>();
    private ArrayList<JTextField> txtResultsList = new ArrayList<>();
    private List<String> subjectList, subjectList2;
    private JComboBox cmbSubjectList, cmbSubjectList2;
    private Font font1, font2, font3;
    int[] totalScore;
    private ResultsDAO resultsDAO;
    private UploadResultsPOJO resultsPOJO;
    private String studentEmail;

    public UploadResultsGUI(String email) {
        setTitle("Matric Resutls");
        //Changes the default java logo
        try {
            BufferedImage customIconImage = ImageIO.read(new File("Logo2.jpg"));
            // Set the custom icon for the JFrame
            setIconImage(customIconImage);
        } catch (IOException ex) {
            // Handle any errors while loading the image (optional)
            ex.printStackTrace();
        }
        font1 = new Font("Times New Roman", Font.BOLD, 28);
        font2 = new Font("Times New Roman", Font.ITALIC, 22);
        font3 = new Font("Arial", Font.BOLD, 15);

        this.studentEmail = email;

        lblHeading = new JLabel("Upload   Matric");
        lblHeading2 = new JLabel("Results");
        //lblHeading.setHorizontalAlignment(SwingConstants.CENTER);
        lblHeading.setFont(font1);
        lblHeading2.setFont(font1);
        lblHeading.setForeground(new Color(10, 10, 10));
        lblHeading2.setForeground(new Color(10, 10, 10));
        lblSubjects = new JLabel("Subjects");
        lblSubjects.setFont(font3);
        lblResults = new JLabel("%");
        lblResults.setFont(font3);
        lblTotalScore = new JLabel("Total APS:");
        lblTotalScore.setFont(font3);

        pnNorth = new JPanel();
        pnNorth.setBackground(new Color(15, 194, 252));
        pnCenter = new JPanel();
        pnCenter.setBackground(new Color(15, 194, 252));
        pnSouth = new JPanel();
        resultsDAO = new ResultsDAO();
        resultsPOJO = new UploadResultsPOJO();

        lblDelete = new JLabel("Select Subject to Delete: ");
        lblDelete.setFont(font3);
        subjectList = resultsDAO.getEnrolledSubjects(studentEmail);
        cmbSubjectList = new JComboBox(subjectList.toArray());
        cmbSubjectList.setSelectedIndex(-1);
        cmbSubjectList.setFont(font3);

        lblUpdate = new JLabel("Select Subject to Update: ");
        lblUpdate.setFont(font3);
        subjectList2 = resultsDAO.getEnrolledSubjects(studentEmail);
        cmbSubjectList2 = new JComboBox(subjectList2.toArray());
        cmbSubjectList2.setSelectedIndex(-1);
        cmbSubjectList2.setFont(font3);

        ArrayList<String> subjects = resultsDAO.getSubjectList();
        Set<String> selectedSubjects = new HashSet<>();

        for (int i = 0; i < 7; i++) {
            JComboBox<String> comboBox = new JComboBox<>(subjects.toArray(new String[0]));
            comboBox.setSelectedIndex(-1);
            comboBox.addActionListener(e -> {
                JComboBox<String> source = (JComboBox<String>) e.getSource();
                String selectedSubject = (String) source.getSelectedItem();

                // Check if the subject has already been selected
                if (selectedSubject != null && selectedSubjects.contains(selectedSubject)) {
                    source.setSelectedIndex(-1); // Deselect the subject

                    // Show a message dialog indicating that the subject has already been selected
                    JOptionPane.showMessageDialog(null, "The subject has already been selected.", "Duplicate Selection", JOptionPane.WARNING_MESSAGE);
                } else {
                    selectedSubjects.add(selectedSubject); // Add the selected subject to the set
                }
            });

            cboSubjectsList.add(comboBox);
            txtResultsList.add(new JTextField(3));
        }

        txtTotalScore = new JTextField(3);
        txtTotalScore.setEditable(false);

        btnBack = new JButton("Back");
        btnShowAPS = new JButton("Show APS");
        btnNext = new JButton("Next");
        btnDelete = new JButton("Delete");
        btnUpdate = new JButton("Update");

    }

    void setResultsGUI() {
        pnNorth.setLayout(new GridLayout(2, 4));
        pnCenter.setLayout(new GridLayout(10, 3));
        pnSouth.setLayout(new GridLayout(1, 5));

        pnNorth.add(new JLabel());
        pnNorth.add(lblHeading);
        pnNorth.add(lblHeading2);
        pnNorth.add(new JLabel());

        pnNorth.add(lblDelete);
        pnNorth.add(cmbSubjectList);
        pnNorth.add(lblUpdate);
        pnNorth.add(cmbSubjectList2);

        pnCenter.add(new JLabel()); // Empty label for spacing
        pnCenter.add(lblSubjects);
        pnCenter.add(lblResults);

        for (int i = 0; i < 7; i++) {
            pnCenter.add(new JLabel("Subject " + (i + 1) + ":"));
            pnCenter.add(cboSubjectsList.get(i));
            pnCenter.add(txtResultsList.get(i));
        }

        pnCenter.add(lblTotalScore);
        pnCenter.add(new JLabel());
        pnCenter.add(txtTotalScore);

        pnSouth.add(btnBack);
        btnBack.setFont(font2);
        btnBack.setBackground(Color.red);

        pnSouth.add(btnShowAPS);
        btnShowAPS.setFont(font2);
        btnShowAPS.setBackground(Color.GRAY);

        pnSouth.add(btnDelete);
        btnDelete.setFont(font2);
        btnDelete.setEnabled(false);
//        btnDelete.setBackground(new Color(39, 214, 53));

        pnSouth.add(btnUpdate);
        btnUpdate.setFont(font2);
        btnUpdate.setBackground(new Color(19, 118, 201));
        btnUpdate.setEnabled(false);

        pnSouth.add(btnNext);
        btnNext.setFont(font2);
        btnNext.setBackground(new Color(39, 214, 53));

        add(pnNorth, BorderLayout.NORTH);
        add(pnCenter, BorderLayout.CENTER);
        add(pnSouth, BorderLayout.SOUTH);

        btnBack.addActionListener(this);
        btnShowAPS.addActionListener(this);
        btnNext.addActionListener(this);
        btnDelete.addActionListener(this);
        btnUpdate.addActionListener(this);
        cmbSubjectList.addItemListener(this);
        cmbSubjectList2.addItemListener(this);

        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setSize(900, 600);
        this.setLocationRelativeTo(null);
        this.setVisible(true);

    }
    // Calculate the total score

    public int calculateApsScore() {

        int[] percentageValues = new int[7];
        for (int i = 0; i < 7; i++) {
            percentageValues[i] = Integer.parseInt(txtResultsList.get(i).getText());
        }

        int totalScore = 0;

        for (int i = 0; i < percentageValues.length; i++) {
            int percentage = percentageValues[i];

            if (percentage < 0 || percentage > 100) {
                throw new IllegalArgumentException("Invalid percentage value: " + percentage);
            }

            if (percentage >= 80) {
                totalScore += 7;
            } else if (percentage >= 70) {
                totalScore += 6;
            } else if (percentage >= 60) {
                totalScore += 5;
            } else if (percentage >= 50) {
                totalScore += 4;
            } else if (percentage >= 40) {
                totalScore += 3;
            } else if (percentage >= 30) {
                totalScore += 2;
            } else if (percentage >= 0) {
                totalScore += 1;
            }
        }

        return totalScore;
    }

    public int[] getTotalScore() {
        int[] totalScore = new int[4];
        return totalScore;
    }

    private boolean isInputValid() {
        for (JTextField textField : txtResultsList) {
            try {
                int percentage = Integer.parseInt(textField.getText());
                if (percentage < 0 || percentage > 100) {
                    return false;
                }
            } catch (NumberFormatException ex) {
                return false;
            }
        }
        return true;
    }

    private void populateComboBox() {
        cmbSubjectList.removeAllItems();
        cmbSubjectList.addItem("---no selection made---");

        for (String subject : resultsDAO.getEnrolledSubjects(studentEmail)) {
            cmbSubjectList.addItem(subject);
        }
        cmbSubjectList.setSelectedIndex(0);

//        // Enable btnDelete when a subject is selected
//        if (cmbSubjectList.getSelectedIndex() > 0) {
//            btnDelete.setEnabled(true);
//        } else {
//            btnDelete.setEnabled(false);
//        }
    }

//    private void populateComboBox() {
//        cmbSubjectList.removeAllItems();
//        cmbSubjectList.addItem("---no selection made---");
//
//        for (String subject : resultsDAO.getEnrolledSubjects(studentEmail)) {
//            cmbSubjectList.addItem(subject);
//        }
//        cmbSubjectList.setSelectedIndex(0);
//    }
    private void populateComboBox2() {
        cmbSubjectList2.removeAllItems();
        cmbSubjectList2.addItem("---no selection made---");

        for (String subject : resultsDAO.getEnrolledSubjects(studentEmail)) {
            cmbSubjectList2.addItem(subject);
        }
        cmbSubjectList2.setSelectedIndex(0);
    }

    private void updateTotalAPSAfterDeletion() {
        updateTotalAPS(); // Update the total APS
    }

    private void resetForm() {
        for (JComboBox<String> cboSubject : cboSubjectsList) {
            cboSubject.setSelectedIndex(-1);
        }
        for (JTextField textField : txtResultsList) {
            textField.setText("");
        }

        txtTotalScore.setText("");
    }

    private void updateTotalAPS() {
        int newTotalScore = calculateApsScore();
        txtTotalScore.setText(String.valueOf(newTotalScore));
        resultsDAO.updateTotalAps(newTotalScore, studentEmail);
    }

    private void updateSubjectFields(UploadResultsPOJO resultsPOJO, String selectedSubject) {
        cboSubjectsList.get(0).setSelectedItem(selectedSubject);
        txtResultsList.get(0).setText(String.valueOf(resultsPOJO.getResults1()));
        btnUpdate.setEnabled(true);

        ArrayList<UploadResultsPOJO> remainingResults = resultsDAO.getRemainingResults(studentEmail, selectedSubject);

        Set<String> selectedSubjects = new HashSet<>();

        for (int i = 1; i < 7; i++) {
            if (i - 1 < remainingResults.size()) {
                String subject = remainingResults.get(i - 1).getSubjects();
                selectedSubjects.add(subject);

                cboSubjectsList.get(i).addItem(subject);
                txtResultsList.get(i).setText(String.valueOf(remainingResults.get(i - 1).getResults1()));
            } else {
                cboSubjectsList.get(i).setSelectedIndex(-1);
                txtResultsList.get(i).setText("");
            }
        }

        ArrayList<String> subjects = resultsDAO.getSubjectList();
        for (int i = 1; i < 7; i++) {
            JComboBox<String> comboBox = cboSubjectsList.get(i);
            for (String subject : subjects) {
                if (!selectedSubjects.contains(subject)) {
                    comboBox.addItem(subject);
                }
            }
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnBack) {
            N_O_K_GUI nokDetails = new N_O_K_GUI(studentEmail);
            nokDetails.setN_O_K_GUI();
            dispose();
        }
        if (e.getSource() == btnShowAPS) {
            try {
                int totalScore = calculateApsScore();
                // Display the total score in the text field
                txtTotalScore.setText(String.valueOf(totalScore));

                // Create a list of UploadResultsPOJO objects
                ArrayList<UploadResultsPOJO> resultsList = new ArrayList<>();
                for (int i = 0; i < 7; i++) {
                    String subject = (String) cboSubjectsList.get(i).getSelectedItem();
                    int result = Integer.parseInt(txtResultsList.get(i).getText());
                    resultsList.add(new UploadResultsPOJO(subject, result));
                }

                // Insert the results and total APS score into the database
                resultsDAO.insertResults(resultsList, totalScore, studentEmail);

            } catch (IllegalArgumentException ex) {
                JOptionPane.showMessageDialog(UploadResultsGUI.this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
        if (e.getSource() == btnDelete) {
            String selectedSubject = (String) cmbSubjectList.getSelectedItem();
            int confirm = JOptionPane.showConfirmDialog(null, "Do you really want to delete the selected record?");

            if (confirm == JOptionPane.YES_OPTION) {
                boolean delete = resultsDAO.deleteResults(selectedSubject, studentEmail);

                if (delete) {
                    JOptionPane.showMessageDialog(null, "You have successfully deleted the record of the Subject with subject name: " + selectedSubject);
                    populateComboBox();
                    updateTotalAPSAfterDeletion();
                    resetForm();
                    btnDelete.setEnabled(false);

//                    // After deletion, reset the corresponding text field
//                    int selectedIndex = cmbSubjectList.getSelectedIndex();
//                    if (selectedIndex != -1) {
//                        txtResultsList.get(selectedIndex).setText(""); // Set the text field to empty
//                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Failed to delete the record of the Subject.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        } //        if (e.getSource() == btnDelete) {
        //            String selectedSubject = (String) cmbSubjectList.getSelectedItem();
        //            int confirm = JOptionPane.showConfirmDialog(null, "Do you really want to delete the selected record?");
        //
        //            if (confirm == JOptionPane.YES_OPTION) {
        //                //String email = getEmailFromSelectedSubject(selectedSubject); // Replace this with the method to get the corresponding email
        //                boolean delete = resultsDAO.deleteResults(selectedSubject, studentEmail);
        //
        //                if (delete) {
        //                    JOptionPane.showMessageDialog(null, "You have successfully deleted the record of the Subject with subject name: " + selectedSubject);
        //                    populateComboBox();
        //                    updateTotalAPSAfterDeletion();
        //                    resetForm();
        //                    btnDelete.setEnabled(false);
        //
        //                    // After deletion, reset the corresponding text field
        //                    int selectedIndex = cmbSubjectList.getSelectedIndex();
        //                    if (selectedIndex != -1) {
        //                        txtResultsList.get(selectedIndex).setText(""); // Set the text field to empty
        //                    }
        //                } else {
        //                    JOptionPane.showMessageDialog(null, "Failed to delete the record of the Subject.", "Error", JOptionPane.ERROR_MESSAGE);
        //                }
        //            }
        //        }
        else if (e.getSource() == btnUpdate) {
            if (isInputValid()) {
                String selectedSubject = (String) cmbSubjectList2.getSelectedItem();
                int updatedPercentage = Integer.parseInt(txtResultsList.get(0).getText());

                resultsPOJO = new UploadResultsPOJO(studentEmail, selectedSubject, updatedPercentage);

                // Prompt the user to confirm the update
                int confirm = JOptionPane.showConfirmDialog(null, "Do you really want to update the selected record?");

                if (confirm == JOptionPane.YES_OPTION) {
                    boolean updateSuccessful = resultsDAO.updateResults(resultsPOJO);

                    if (updateSuccessful) {
                        JOptionPane.showMessageDialog(
                                pnCenter,
                                "Information updated successfully."
                        );

                        // Update total APS and reset the form
                        updateTotalAPS();
                        resetForm();
                    } else {
                        JOptionPane.showMessageDialog(
                                pnCenter,
                                "Failed to update Subject information.",
                                "Error",
                                JOptionPane.ERROR_MESSAGE
                        );
                    }
                }
            } else {
                JOptionPane.showMessageDialog(pnCenter, "Please correct errors before updating.");
            }
        }
        if (e.getSource() == btnNext) {
            CourseSelectionGUI csGUI = new CourseSelectionGUI(studentEmail);
            csGUI.setC_S_GUI();
            dispose();
        }
    }

    @Override
    public void itemStateChanged(ItemEvent e) {
        if (e.getSource() == cmbSubjectList &&e.getStateChange() == ItemEvent.SELECTED) {
            if (!cmbSubjectList.getSelectedItem().equals("---no selection made---")) {
                String selectedSubject = (String) cmbSubjectList.getSelectedItem();
                resultsPOJO = resultsDAO.getStudSubject(selectedSubject, studentEmail);

                if (resultsPOJO != null) {
                    cboSubjectsList.get(0).setSelectedItem(resultsPOJO.getSubjects());
                    txtResultsList.get(0).setText(String.valueOf(resultsPOJO.getResults1()));
                    btnDelete.setEnabled(true);
                } else {
                    populateComboBox();
                    resetForm();
                    btnDelete.setEnabled(false);
                }
            }
        }
        if (e.getSource() == cmbSubjectList2 && e.getStateChange() == ItemEvent.SELECTED) {
            String selectedSubject = cmbSubjectList2.getSelectedItem().toString();
            if (!selectedSubject.equals("---no selection made---")) {
                resultsPOJO = resultsDAO.getStudSubject(studentEmail, selectedSubject);
                if (resultsPOJO != null) {
                    updateSubjectFields(resultsPOJO, selectedSubject);
                } else {
                    resetForm();
                    btnUpdate.setEnabled(false);
                }
            } else {
                populateComboBox2();
                resetForm();
                btnUpdate.setEnabled(false);
            }
        }
//        if (e.getSource() == cmbSubjectList2 && e.getStateChange() == ItemEvent.SELECTED) {
//            String selectedSubject = cmbSubjectList2.getSelectedItem().toString();
//            if (!selectedSubject.equals("---no selection made---")) {
//                resultsPOJO = resultsDAO.getStudSubject(studentEmail, selectedSubject);
//                if (resultsPOJO != null) {
//                    // Display selected subject at the top
//                    cboSubjectsList.get(0).setSelectedItem(selectedSubject);
//                    txtResultsList.get(0).setText(String.valueOf(resultsPOJO.getResults1()));
//                    btnUpdate.setEnabled(true);
//
//                    // Clear the existing subjects in cboSubjectsList
//                    for (int i = 1; i < 7; i++) {
//                        cboSubjectsList.get(i).removeAllItems();
//                    }
//
//                    // Retrieve and fill in the remaining subject lists and results from the database
//                    ArrayList<UploadResultsPOJO> remainingResults = resultsDAO.getRemainingResults(studentEmail, selectedSubject);
//
//                    // Maintain a set of selected subjects
//                    Set<String> selectedSubjects = new HashSet<>();
//
//                    // Loop to fill all subjects and percentages
//                    for (int i = 1; i < 7; i++) {
//                        if (i - 1 < remainingResults.size()) {
//                            String subject = remainingResults.get(i - 1).getSubjects();
//                            cboSubjectsList.get(i).addItem(subject);
//
//                            // Ensure uniqueness by adding to the selectedSubjects set
//                            selectedSubjects.add(subject);
//
//                            txtResultsList.get(i).setText(String.valueOf(remainingResults.get(i - 1).getResults1()));
//                        } else {
//                            cboSubjectsList.get(i).setSelectedIndex(-1);
//                            txtResultsList.get(i).setText("");
//                        }
//                    }
//
//                    // Populate cboSubjectsList with remaining subjects (if any)
//                    ArrayList<String> subjects = resultsDAO.getSubjectList();
//                    for (int i = 1; i < 7; i++) {
//                        JComboBox<String> comboBox = cboSubjectsList.get(i);
//                        for (String subject : subjects) {
//                            if (!selectedSubjects.contains(subject)) {
//                                comboBox.addItem(subject);
//                            }
//                        }
//                    }
//                }
//            } else {
//                populateComboBox2();
//                resetForm();
//                btnUpdate.setEnabled(false);
//            }
//        }

//      24 October 17:01
//        if (e.getSource() == cmbSubjectList2 && e.getStateChange() == ItemEvent.SELECTED) {
//            String selectedSubject = cmbSubjectList2.getSelectedItem().toString();
//            if (!selectedSubject.equals("---no selection made---")) {
//                resultsPOJO = resultsDAO.getStudSubject(selectedSubject, studentEmail);
//                if (resultsPOJO != null) {
//                    // Display selected subject at the top
//                    cboSubjectsList.get(0).setSelectedItem(resultsPOJO.getSubjects());
//                    txtResultsList.get(0).setText(String.valueOf(resultsPOJO.getResults1()));
//                    btnUpdate.setEnabled(true);
//
//                    // Retrieve and fill in the remaining subject lists and results from the database
//                    ArrayList<UploadResultsPOJO> remainingResults = resultsDAO.getRemainingResults(selectedSubject);
//                    for (int i = 1; i < 7; i++) {
//                        cboSubjectsList.get(i).setSelectedItem(remainingResults.get(i - 1).getSubjects());
//                        txtResultsList.get(i).setText(String.valueOf(remainingResults.get(i - 1).getResults1()));
//                    }
//                }
//            } else {
//                populateComboBox2();
//                resetForm();
//                btnUpdate.setEnabled(false);
//            }
//        }
    }
}
