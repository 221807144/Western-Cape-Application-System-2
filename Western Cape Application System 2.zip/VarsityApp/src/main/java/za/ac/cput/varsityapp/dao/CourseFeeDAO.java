/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.cput.varsityapp.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author user
 */
public class CourseFeeDAO {

    private static final String DATABASE_URL = "jdbc:derby://localhost:1527/VarsityDB";
    private static final String dbUsername = "administrator";
    private static final String dbPassword = "password";

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(DATABASE_URL, dbUsername, dbPassword);
    }

public void retrieveCourses(DefaultTableModel tableModel, String email) {
    try (Connection connection = getConnection()) {                 
        String query = "SELECT COURSE_NAME, INSTITUTION, FEES FROM Enrolmennts WHERE EMAIL = ?";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, email);
        ResultSet resultSet = statement.executeQuery();

        while (resultSet.next()) {
            String courseName = resultSet.getString("COURSE_NAME");
            String institution = resultSet.getString("INSTITUTION");
            double fee = resultSet.getDouble("FEES");
            tableModel.addRow(new Object[]{courseName, institution, fee});
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
}

    public void retrieveBursaries(DefaultTableModel tableModel) {
        try ( Connection connection = getConnection()) {
            String query = "SELECT Course_Name, Bursary_Name FROM Bursaries";
            PreparedStatement statement = connection.prepareStatement(query);
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                String courseName = resultSet.getString("Course_Name");
                String bursaryName = resultSet.getString("Bursary_Name");
                tableModel.addRow(new Object[]{courseName, bursaryName});
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
