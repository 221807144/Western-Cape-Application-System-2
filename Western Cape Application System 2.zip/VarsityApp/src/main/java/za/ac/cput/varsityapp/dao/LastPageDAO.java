/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.cput.varsityapp.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import za.ac.cput.varsityapp.domain.SubmissionPagePOJO;

/**
 *
 * @author user
 */
public class LastPageDAO {

    private static final String DATABASE_URL = "jdbc:derby://localhost:1527/VarsityDB";
    private static final String dbUsername = "administrator";
    private static final String dbPassword = "password";

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(DATABASE_URL, dbUsername, dbPassword);
    }

    public void readCourses(List<SubmissionPagePOJO> dataList, String email) {
        try ( Connection connection = getConnection()) {
            connection.setAutoCommit(false); // Start a transaction

            // Prepare the SQL statement for retrieving courses
            String selectCoursesSQL = "SELECT Institution, Course_Name FROM Enrolmennts WHERE Email = ?";
            try ( PreparedStatement selectStatement = connection.prepareStatement(selectCoursesSQL)) {
                selectStatement.setString(1, email);
                ResultSet resultSet = selectStatement.executeQuery();

                while (resultSet.next()) {
                    String institution = resultSet.getString("Institution");
                    String courseName = resultSet.getString("Course_Name");

                    // Generate and assign the student number for this institution
                    String studentNumber = generateStudentNumber(connection, institution, email);

                    // Create a new SubmissionPagePOJO object and set its properties
                    SubmissionPagePOJO s_p_pojo = new SubmissionPagePOJO();
                    s_p_pojo.setInstitution(institution);
                    s_p_pojo.setCourseName(courseName);
                    s_p_pojo.setStudNum(studentNumber);

                    // Add the object to the list
                    dataList.add(s_p_pojo);
                }

                connection.commit(); // Commit the transaction
            } catch (SQLException e) {
                connection.rollback(); // Rollback the transaction if an error occurs
                e.printStackTrace();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public void saveStudentNumbers(SubmissionPagePOJO s_p_pojo) throws SQLException {
        // Prepare the SQL statement for inserting data into the Submission table
        String insertSubmissionSQL = "INSERT INTO Submission(Email, Institution, Course_Name, Student_Num) VALUES (?, ?, ?, ?)";
 
        try ( Connection connection = getConnection(); // Create a new connection
                  PreparedStatement insertStatement = connection.prepareStatement(insertSubmissionSQL)) {
            insertStatement.setString(1, s_p_pojo.getStudentEmail());
            insertStatement.setString(2, s_p_pojo.getInstitution());
            insertStatement.setString(3, s_p_pojo.getCourseName());
            insertStatement.setString(4, s_p_pojo.getStudNum());
            insertStatement.executeUpdate();
        }
    }


//    22 October(16:48)
    private static Map<String, String> institutionStudentNumbers = new HashMap<>();

private static String generateStudentNumber(Connection connection, String institution, String email) throws SQLException {
    String key = institution + email;

    if (institutionStudentNumbers.containsKey(key)) {
        // If a student number exists for this institution and email, return it
        return institutionStudentNumbers.get(key);
    } else {
        // If no student number exists, generate a new one
        String newStudentNumber = generateNewStudentNumber(connection);
        institutionStudentNumbers.put(key, newStudentNumber);
        return newStudentNumber;
    }
}

private static String generateNewStudentNumber(Connection connection) throws SQLException {
    // Generate a new 10-digit student number
    String studentNumber = generateRandomStudentNumber();

    // Check if the generated student number already exists
    try (PreparedStatement statement = connection.prepareStatement(
            "SELECT 1 FROM Submission WHERE Student_Num = ?")) {
        statement.setString(1, studentNumber);
        ResultSet resultSet = statement.executeQuery();
        if (resultSet.next()) {
            // If the generated student number already exists, generate a new one recursively
            return generateNewStudentNumber(connection);
        }
    }

    return studentNumber;
}

private static String generateRandomStudentNumber() {
    Random random = new Random();
    long min = 1000000000L;  // Minimum 10-digit number
    long max = 9999999999L;  // Maximum 10-digit number
    long studentNumber = min + ((long) (random.nextDouble() * (max - min)));
    return String.valueOf(studentNumber);
}


}
