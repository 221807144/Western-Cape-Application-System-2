/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package za.ac.cput.varsityapp.domain;

/**
 *
 * @author Skhoma
 */

public class User {
    private String name;
    private String surname;
    private String username;
    private String dateOfBirth;
    private String password;
    private String firstSchool;
    private String firstPet;
    private String cityBorn;
    private String oldestCousin;

    public User() {
    }
    

    public User(String name, String surname, String username, String dateOfBirth, String password,
                String firstSchool, String firstPet, String cityBorn, String oldestCousin) {
        this.name = name;
        this.surname = surname;
        this.username = username;
        this.dateOfBirth = dateOfBirth;
        this.password = password;
        this.firstSchool = firstSchool;
        this.firstPet = firstPet;
        this.cityBorn = cityBorn;
        this.oldestCousin = oldestCousin;
    }

    // Getters and setters for all the properties

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getFirstSchool() {
        return firstSchool;
    }

    public void setFirstSchool(String firstSchool) {
        this.firstSchool = firstSchool;
    }

    public String getFirstPet() {
        return firstPet;
    }

    public void setFirstPet(String firstPet) {
        this.firstPet = firstPet;
    }

    public String getCityBorn() {
        return cityBorn;
    }

    public void setCityBorn(String cityBorn) {
        this.cityBorn = cityBorn;
    }

    public String getOldestCousin() {
        return oldestCousin;
    }

    public void setOldestCousin(String oldestCousin) {
        this.oldestCousin = oldestCousin;
    }

    @Override
    public String toString() {
        return "User{" +
                "name='" + name + '\'' +
                ", surname='" + surname + '\'' +
                ", username='" + username + '\'' +
                ", dateOfBirth='" + dateOfBirth + '\'' +
                ", password='" + password + '\'' +
                ", firstSchool='" + firstSchool + '\'' +
                ", firstPet='" + firstPet + '\'' +
                ", cityBorn='" + cityBorn + '\'' +
                ", oldestCousin='" + oldestCousin + '\'' +
                '}';
    }
}

