/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.cput.varsityapp.views;

import java.awt.*;
import za.ac.cput.varsityapp.domain.N_O_K_DetailsPOJO;
import za.ac.cput.varsityapp.dao.N_O_K_DetailsDAO;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import javax.swing.*;

/**
 *
 * @author Asimbonge Mbende(221090754)
 */
public class N_O_K_GUI extends JFrame implements ActionListener, ItemListener {

    private JPanel pnNorth, pnCenter, pnSouth;

    private ArrayList<String> emailList;
    private JLabel lblDelete;
    private JComboBox cmbEmailList;

    private JLabel lblUpdate;
    private ArrayList<String> emailList2;
    private JComboBox cmbEmailList2;

    private JLabel lblTitle;
    private JComboBox cboTitle;
    private JLabel lblErrorTitle;

    private JLabel lblFirstName;
    private JTextField txtFirstName;
    private JLabel lblErrorFirstName;

    private JLabel lblLastName;
    private JTextField txtLastName;
    private JLabel lblErrorLastName;

    private JLabel lblGender;
    private JPanel panelGender;
    private JRadioButton radFemale;
    private JRadioButton radMale;
    private JLabel lblErrorGender;
    private ButtonGroup genderButtonGroup;

    private JLabel lblEmail;
    private JTextField txtEmail;
    private JLabel lblErrorEmail;

    private JLabel lblCellNo;
    private JTextField txtCellNo;
    private JLabel lblErrorCellNo;

    private JLabel lblAddress;
    private JTextField txtAddress;
    private JLabel lblErrorAddress;

    private JLabel lblTerms;
    private JCheckBox chkTerms;
    private JLabel lblErrorTerms;

    private JButton btnNext;
    private JButton btnClear;
    private JButton btnBack;
    private JButton btnDelete;
    private JButton btnUpdate;
    private Font font1, font2, font3, font4;
    N_O_K_DetailsDAO n_o_kDAO;
    N_O_K_DetailsPOJO n_o_k;
    private String studentEmail;

    //this constructor is where we will initiate our instance  valiables
    public N_O_K_GUI(String email) {
        super("Next of Kin Personal Details");
        //Changes the default java logo
        try {
            BufferedImage customIconImage = ImageIO.read(new File("Logo2.jpg"));

            setIconImage(customIconImage);
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        font1 = new Font("Times New Roman", Font.BOLD, 28);
        font2 = new Font("Times New Roman", Font.ITALIC, 22);
        font4 = new Font("Times New Roman", Font.ITALIC, 19);
        font3 = new Font("Arial", Font.BOLD, 15);
        this.studentEmail = email;
        pnNorth = new JPanel();
        pnCenter = new JPanel();
        pnSouth = new JPanel();
        n_o_kDAO = new N_O_K_DetailsDAO();
        n_o_k = new N_O_K_DetailsPOJO();

        lblDelete = new JLabel("Select Email to Delete: ");
        lblDelete.setFont(font3);
        emailList = n_o_kDAO.getEmails(studentEmail);
        cmbEmailList = new JComboBox(emailList.toArray());
        cmbEmailList.setFont(font3);

        lblUpdate = new JLabel("Select Email to Update: ");
        lblUpdate.setFont(font3);
        emailList2 = n_o_kDAO.getEmails(studentEmail);
        cmbEmailList2 = new JComboBox(emailList2.toArray());
        cmbEmailList2.setFont(font3);

        lblTitle = new JLabel("Title: ");
        lblTitle.setFont(font1);
        String listOfTitles[] = {"Dr", "Adv", "Judge", "Rev", "Prof", "Mr", "Mrs", "Miss"};
        cboTitle = new JComboBox(listOfTitles);
        cboTitle.setFont(font2);
        lblErrorTitle = new JLabel("*required.Please provide title");
        lblErrorTitle.setFont(font3);
        lblErrorTitle.setForeground(Color.red);
        lblErrorTitle.setVisible(false);

        lblFirstName = new JLabel("First Name: ");
        lblFirstName.setFont(font1);
        txtFirstName = new JTextField(20);
        txtFirstName.setFont(font2);
        lblErrorFirstName = new JLabel("*required.Please provide First Name");
        lblErrorFirstName.setFont(font3);
        lblErrorFirstName.setForeground(Color.red);
        lblErrorFirstName.setVisible(false);

        lblLastName = new JLabel("Last Name: ");
        lblLastName.setFont(font1);
        txtLastName = new JTextField(20);
        txtLastName.setFont(font2);
        lblErrorLastName = new JLabel("*required.Please provide Last Name");
        lblErrorLastName.setFont(font3);
        lblErrorLastName.setForeground(Color.red);
        lblErrorLastName.setVisible(false);

        lblGender = new JLabel("Gender: ");
        lblGender.setFont(font1);

        panelGender = new JPanel();
        radFemale = new JRadioButton("Female");
        radFemale.setFont(font2);
        radMale = new JRadioButton("Male");
        radMale.setFont(font2);
        genderButtonGroup = new ButtonGroup();
        genderButtonGroup.add(radFemale);
        genderButtonGroup.add(radMale);
        panelGender.setLayout(new GridLayout(1, 2));
        radFemale.setSelected(true);//make the female option default
        panelGender.add(radFemale);
        panelGender.add(radMale);
        lblErrorGender = new JLabel("*required.Please provide Gender");
        lblErrorGender.setFont(font3);
        lblErrorGender.setForeground(Color.red);
        lblErrorGender.setVisible(false);

        lblEmail = new JLabel("Email: ");
        lblEmail.setFont(font1);
        txtEmail = new JTextField(20);
        txtEmail.setFont(font2);
        lblErrorEmail = new JLabel("*required.Please provide valid Email");
        lblErrorEmail.setFont(font3);
        lblErrorEmail.setForeground(Color.red);
        lblErrorEmail.setVisible(false);

        lblCellNo = new JLabel("Cell Number: ");
        lblCellNo.setFont(font1);
        txtCellNo = new JTextField();
        txtCellNo.setFont(font2);
        lblErrorCellNo = new JLabel("*input must contain exactly 10 numbers");
        lblErrorCellNo.setFont(font3);
        lblErrorCellNo.setForeground(Color.red);
        lblErrorCellNo.setVisible(false);

        lblAddress = new JLabel("Address: ");
        lblAddress.setFont(font1);
        txtAddress = new JTextField();
        txtAddress.setFont(font2);
        lblErrorAddress = new JLabel("*required.Please provide address");
        lblErrorAddress.setFont(font3);
        lblErrorAddress.setForeground(Color.red);
        lblErrorAddress.setVisible(false);

        lblTerms = new JLabel("Terms and Conditions: ");
        lblTerms.setFont(font1);
        chkTerms = new JCheckBox("I agree to the terms and conditions");
        chkTerms.setFont(font4);
        lblErrorTerms = new JLabel("*required.Please accept the Ts & Cs");
        lblErrorTerms.setFont(font3);
        lblErrorTerms.setForeground(Color.red);
        lblErrorTerms.setVisible(false);

        btnNext = new JButton("Next");
        btnClear = new JButton("Clear");
        btnBack = new JButton("Back");
        btnDelete = new JButton("Delete");
        btnUpdate = new JButton("Update");
        btnNext.setEnabled(false);

    }

    void setN_O_K_GUI() {

        //pnCenter place all gui components on the frame....gridLayout(9 Rows and 3 Columns )
        pnNorth.setLayout(new FlowLayout());
        pnCenter.setLayout(new GridLayout(8, 3));
        pnSouth.setLayout(new GridLayout(1, 5));

        pnNorth.add(lblDelete);
        pnNorth.add(cmbEmailList);

        pnNorth.add(lblUpdate);
        pnNorth.add(cmbEmailList2);

        pnCenter.add(lblTitle);
        pnCenter.add(cboTitle);
        pnCenter.add(lblErrorTitle);

        pnCenter.add(lblFirstName);
        pnCenter.add(txtFirstName);
        pnCenter.add(lblErrorFirstName);

        pnCenter.add(lblLastName);
        pnCenter.add(txtLastName);
        pnCenter.add(lblErrorLastName);

        pnCenter.add(lblGender);
        pnCenter.add(panelGender);
        pnCenter.add(lblErrorGender);

        pnCenter.add(lblEmail);
        pnCenter.add(txtEmail);
        pnCenter.add(lblErrorEmail);

        pnCenter.add(lblCellNo);
        pnCenter.add(txtCellNo);
        pnCenter.add(lblErrorCellNo);

        pnCenter.add(lblAddress);
        pnCenter.add(txtAddress);
        pnCenter.add(lblErrorAddress);

        pnCenter.add(lblTerms);
        pnCenter.add(chkTerms);
        pnCenter.add(lblErrorTerms);

        pnSouth.add(btnBack);
        btnBack.setFont(font2);
        btnBack.setBackground(Color.red);

        pnSouth.add(btnClear);
        btnClear.setFont(font2);
        btnClear.setBackground(Color.GRAY);
        btnClear.setEnabled(false);

        pnSouth.add(btnUpdate);
        btnUpdate.setFont(font2);
        btnUpdate.setBackground(new Color(19, 118, 201));
        btnUpdate.setEnabled(false);

        pnSouth.add(btnDelete);
        btnDelete.setFont(font2);
        btnDelete.setEnabled(false);

        pnSouth.add(btnNext);
        btnNext.setFont(font2);
        btnNext.setBackground(new Color(39, 214, 53));

        btnNext.addActionListener(this);
        btnClear.addActionListener(this);
        btnBack.addActionListener(this);
        btnDelete.addActionListener(this);
        btnUpdate.addActionListener(this);
        chkTerms.addActionListener(this);
        cmbEmailList.addItemListener(this);
        cmbEmailList2.addItemListener(this);

        add(pnNorth, BorderLayout.NORTH);
        add(pnCenter, BorderLayout.CENTER);
        add(pnSouth, BorderLayout.SOUTH);
        //To make the GUI Visible and set it
        populateComboBox();
        populateComboBox2();
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setSize(900, 600);
        this.setLocationRelativeTo(null);
        this.setVisible(true);

    }
    // Method to set placeholder text and color for a JTextField

    private void setPlaceholder(JTextField textField, String placeholder, Color placeholderColor) {
        textField.setText(placeholder);
        textField.setForeground(placeholderColor);

        textField.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {
                if (textField.getText().equals(placeholder)) {
                    textField.setText("");
                    textField.setForeground(Color.BLACK);
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if (textField.getText().isEmpty()) {
                    textField.setText(placeholder);
                    textField.setForeground(placeholderColor);
                }
            }
        });
    }

    private void populateComboBox() {
        cmbEmailList.removeAllItems();
        cmbEmailList.addItem("---no selection made---");

        for (String email : n_o_kDAO.getEmails(studentEmail)) {
            cmbEmailList.addItem(email);
        }
        cmbEmailList.setSelectedIndex(0);
    }

    private void populateComboBox2() {
        cmbEmailList2.removeAllItems();
        cmbEmailList2.addItem("---no selection made---");

        for (String email : n_o_kDAO.getEmails(studentEmail)) {
            cmbEmailList2.addItem(email);
        }
        cmbEmailList2.setSelectedIndex(0);
    }

    public boolean isInputValid() {
        boolean valid = true;
        if (cboTitle.getSelectedIndex() == -1) {
            valid = false;
            lblErrorTitle.setVisible(true);
        } else {
            lblErrorTitle.setVisible(false);
        }

        // Validate first name
        String firstName = txtFirstName.getText();
        if (txtFirstName.getText().equals("")) {
            valid = false;
            lblErrorFirstName.setVisible(true);
        } else if (firstName.length() < 2 || !firstName.matches("^[a-zA-Z ]+$")) {
            valid = false;
            lblErrorFirstName.setText("Please provide valid first name");
            lblErrorFirstName.setVisible(true);
        } else {
            lblErrorFirstName.setVisible(false);
        }

        // Validate last name
        String lastName = txtLastName.getText();
        if (txtLastName.getText().equals("")) {
            valid = false;
            lblErrorLastName.setVisible(true);
        } else if (lastName.length() < 2 || !lastName.matches("^[a-zA-Z ]+$")) {
            valid = false;
            lblErrorLastName.setText("Please provide valid last name");
            lblErrorLastName.setVisible(true);
        } else {
            lblErrorLastName.setVisible(false);
        }

        if (!radFemale.isSelected() && !radMale.isSelected()) {
            valid = false;
            lblErrorGender.setText("Please select a gender");
            lblErrorGender.setVisible(true);
        } else {
            lblErrorGender.setVisible(false);
        }

        if (!org.apache.commons.validator.routines.EmailValidator.getInstance().isValid(txtEmail.getText())) {
            valid = false;
            lblErrorEmail.setVisible(true);
        } else {
            lblErrorEmail.setVisible(false);
        }

        String input = txtCellNo.getText();
        if (input.length() != 10) {
            valid = false;

            lblErrorCellNo.setVisible(true);
            // \\d+ is a regular expression matches one or more digits
        } else if (!input.matches("\\d+")) {
            lblErrorCellNo.setText("*Input must only contain digits");
            lblErrorCellNo.setVisible(true);
        } else {
            lblErrorCellNo.setVisible(false);
        }

        // Validate address
        String address = txtAddress.getText();
        if (address.length() < 5 || !address.matches("[a-zA-Z0-9#,-/ ]+")) {
            valid = false;
            lblErrorAddress.setText("*required.Please provide valid address");
            lblErrorAddress.setVisible(true);
        } else {
            lblErrorAddress.setVisible(false);
        }

        return valid;
    }

    void resetForm() {
        cboTitle.setSelectedIndex(-1);
        txtFirstName.setText("");
        txtLastName.setText("");
        radFemale.setSelected(true);
        txtEmail.setText("");
        txtCellNo.setText("");
        txtAddress.setText("");
        chkTerms.setSelected(false);
        cmbEmailList.setSelectedIndex(0);
        cmbEmailList2.setSelectedIndex(0);
        btnNext.setEnabled(false);
        btnClear.setEnabled(false);

        //reset error labels
        lblErrorFirstName.setVisible(false);
        lblErrorLastName.setVisible(false);
        lblErrorEmail.setVisible(false);

        lblErrorCellNo.setVisible(false);
        lblErrorAddress.setVisible(false);
        setPlaceholder(txtFirstName, "e.g John", Color.GRAY);
        setPlaceholder(txtLastName, "e.g Smith", Color.GRAY);
        setPlaceholder(txtEmail, "e.g johnsmith@gmail.com", Color.GRAY);
        setPlaceholder(txtCellNo, "e.g 0123456789", Color.GRAY);
        setPlaceholder(txtAddress, "e.g District 6,Cape Town,8001", Color.GRAY);

    }

    private void handleTermsCheckBox() {
        if (chkTerms.isSelected()) {
            String title = cboTitle.getSelectedItem() != null ? cboTitle.getSelectedItem().toString() : "";
            String name = txtFirstName.getText();
            String surname = txtLastName.getText();
            String gender = radFemale.isSelected() ? "Female" : "Male";
            String email = txtEmail.getText();
            String cellNumber = txtCellNo.getText();
            String address = txtAddress.getText();

            if (title.isEmpty() || name.isEmpty() || surname.isEmpty() || gender.isEmpty() || email.isEmpty() || cellNumber.isEmpty() || address.isEmpty()) {
                lblErrorTerms.setText("Please fill in all the required fields.");
                lblErrorTerms.setVisible(true);
                btnNext.setEnabled(false);
                btnClear.setEnabled(false);
            } else {
                lblErrorTerms.setVisible(false);
                btnNext.setEnabled(true);
                btnClear.setEnabled(true);
            }
        } else {
            lblErrorTerms.setVisible(true);
            btnNext.setEnabled(false);
            btnClear.setEnabled(false);
        }
    }

    @Override

    public void actionPerformed(ActionEvent e) {
        String title = cboTitle.getSelectedItem() != null ? cboTitle.getSelectedItem().toString() : "";
        String name = txtFirstName.getText();
        String surname = txtLastName.getText();
        String gender = radFemale.isSelected() ? "Female" : "Male";
        String email = txtEmail.getText();
        String cellNumber = txtCellNo.getText();
        String address = txtAddress.getText();

        if (e.getSource() == btnNext) {
            if (isInputValid()) {
                N_O_K_DetailsPOJO n_o_k = new N_O_K_DetailsPOJO(studentEmail, title, name, surname, gender, email, cellNumber, address);
                n_o_kDAO.save(n_o_k);
                resetForm();
                JOptionPane.showMessageDialog(pnCenter, "Success: Next of Kin's Information saved");
                UploadResultsGUI results = new UploadResultsGUI(studentEmail);
                results.setResultsGUI();
                dispose();
            } else {
//                JOptionPane.showMessageDialog(this, "Please correct errors before saving.");
                JOptionPane.showMessageDialog(this, "Please correct errors before saving.", "Error Message", JOptionPane.ERROR_MESSAGE);

            }
        }

        if (e.getSource() == btnClear) {
            resetForm();
        }
        if (e.getSource() == btnDelete) {
            String selectedEmail = (String) cmbEmailList.getSelectedItem();
            int confirm = JOptionPane.showConfirmDialog(null, "Do you really want to delete the selected record?");

            if (confirm == JOptionPane.YES_OPTION) {
                boolean delete = n_o_kDAO.deleteStudent(selectedEmail, studentEmail);

                if (delete) {
                    JOptionPane.showMessageDialog(null, "You have successfully deleted the record of the Next of Kin, with Next of Kin Email: " + selectedEmail);
                    populateComboBox();
                    resetForm();
                    btnDelete.setEnabled(false);
                } else {
                    JOptionPane.showMessageDialog(null, "Failed to delete the record of the Next of Kin.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
        if (e.getSource() == btnUpdate) {
            if (isInputValid()) {
                N_O_K_DetailsPOJO updatedNOK = new N_O_K_DetailsPOJO(studentEmail,
                        cboTitle.getSelectedItem().toString(),
                        txtFirstName.getText(),
                        txtLastName.getText(),
                        radFemale.isSelected() ? "Female" : "Male",
                        txtEmail.getText(),
                        txtCellNo.getText(),
                        txtAddress.getText()
                );
                int confirm = JOptionPane.showConfirmDialog(null, "Do you really want to update the selected record?");
                if (confirm == JOptionPane.YES_OPTION) {
                    // Here, you should update the n_o_k information using the DAO's update method
                    boolean updateSuccessful = n_o_kDAO.updateNOK(updatedNOK);

                    if (updateSuccessful) {
                        JOptionPane.showMessageDialog(
                                pnCenter,
                                "Information updated successfully."
                        );

                        // Optionally, you might want to repopulate the combo boxes
                        populateComboBox();
                        populateComboBox2();
//                    resetForm();
                    } else {
                        JOptionPane.showMessageDialog(
                                pnCenter,
                                "Failed to update Next of Kin information.",
                                "Error",
                                JOptionPane.ERROR_MESSAGE
                        );
                    }
                }
            } else {
                JOptionPane.showMessageDialog(pnCenter, "Please correct errors before updating.");
            }
        } else if (e.getSource() == btnBack) {
            ApplicantDetailsGUI persDetails = new ApplicantDetailsGUI(studentEmail);
            persDetails.setP_D_GUI();
            dispose();
        }

        if (e.getSource() == chkTerms) {
            handleTermsCheckBox();
        }
    }

    @Override
    public void itemStateChanged(ItemEvent e) {
        if (e.getStateChange() == ItemEvent.SELECTED) {
            if (!cmbEmailList.getSelectedItem().equals("---no selection made---")) {
                String selectedEmail = (String) cmbEmailList.getSelectedItem();
                n_o_k = n_o_kDAO.getStudEmail(studentEmail, selectedEmail);

                if (n_o_k != null) {
                    cboTitle.setSelectedItem(n_o_k.getTitle());
                    txtFirstName.setText(n_o_k.getFirstName());
                    txtLastName.setText(n_o_k.getLastName());
                    if (n_o_k.getGender().equals("Female")) {
                        radFemale.setSelected(true);
                    } else {
                        radMale.setSelected(true);
                    }
                    txtEmail.setText(n_o_k.getEmail());
                    txtCellNo.setText(n_o_k.getCellNo());
                    txtAddress.setText(n_o_k.getAddress());
                    btnDelete.setEnabled(true);
                    btnClear.setEnabled(true);
                } else {
                    resetForm();
                    btnDelete.setEnabled(false);
                }
            }
        }

        if (e.getSource() == cmbEmailList2 && e.getStateChange() == ItemEvent.SELECTED) {
            String selectedStudNum = cmbEmailList2.getSelectedItem().toString();
            if (!selectedStudNum.equals("---no selection made---")) {
                n_o_k = n_o_kDAO.getStudEmail(studentEmail, selectedStudNum);
                if (n_o_k != null) {
                    cboTitle.setSelectedItem(n_o_k.getTitle());
                    txtFirstName.setText(n_o_k.getFirstName());
                    txtLastName.setText(n_o_k.getLastName());
                    if (n_o_k.getGender().equals("Female")) {
                        radFemale.setSelected(true);
                    } else {
                        radMale.setSelected(true);
                    }
                    txtEmail.setText(n_o_k.getEmail());
                    txtCellNo.setText(n_o_k.getCellNo());
                    txtAddress.setText(n_o_k.getAddress());
                    btnUpdate.setEnabled(true);
                    btnClear.setEnabled(true);
                }
            } else {
                resetForm();
                btnUpdate.setEnabled(false);
                btnClear.setEnabled(false);
            }
        }
    }
}
